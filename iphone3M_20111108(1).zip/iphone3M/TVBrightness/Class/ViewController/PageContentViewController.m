//
//  PageContentViewController.m
//  TVBrightness
//
//  Created by zhang on 9/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PageContentViewController.h"


@implementation PageContentViewController
@synthesize TextView,labTitle,PageControl;

- (id)initWithPageNumber:(int)page
{
    if ((self=[super initWithNibName:@"PageContentViewController" bundle:nil]))
    {
       
        pageNumber = page;
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

// set the label and background color when the view has finished loading
- (void)viewDidLoad
{
    switch (pageNumber) {
        case 0:
            TextView.text=@"                    能效定义\n\n中国国标平板电视能效限定值及能效等级中定义,平板电视能效即平板电视能源效率，单位为坎德拉每瓦(cd/W),其物理意义表示产品在规定测试程序下，平板电视屏幕的实际发光强度与平板电视能耗的比值，是用于表征电视是否节能的物理量";
            labTitle.text=@"能效定义";
            break;
        case 1:
            TextView.text=@"                    亮度定义\n\n用于表征显示器(屏幕)发光明亮程度的物理量，表示人眼对光的强度的感受。其单位为cd/m2(坎德拉/平方米)或nit(尼特)，指与屏幕表面垂直的发光强度与发光面积的比值。普通 电视亮度通常在400cd/m2~500cd/m2";
            labTitle.text=@"亮度定义";
            break;
        case 2:
            TextView.text=@"                    视角定义\n\n中国行业标准中数字液晶显示器测量方法中的定义，规定视角为亮度1/3视角，即屏幕中心亮度减小到1/3时的水平和垂直视角。此外，通常在显示领域里面会使用到半亮度视角，所谓半亮度";
            labTitle.text=@"视角定义";
            break;
        default:
            break;
    }
}



@end
