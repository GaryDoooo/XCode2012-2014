//
//  CheckingImageController.h
//  MMM
//
//  Created by Evangel on 11-5-13.
//  Copyright 2011年 Hp. All rights reserved.
//

#import "MyButton.h"
#import "UserRateView.h"

@protocol CheckingImageControllerDelegate;

@interface CheckingImageController : UIViewController <UserRateViewDelegate>
{
    UIView *upLoadView;
    UIView * buttonView;
    MyButton *btnSubumit;
    MyButton *btnCancel;
    UserRateView *ratingView;
    UIImageView *capturedImageV;
    id <CheckingImageControllerDelegate> delegate;
    id data;
}

@property (nonatomic, retain) id data;
@property (nonatomic, assign) id <CheckingImageControllerDelegate> delegate;
@property (nonatomic, retain) IBOutlet UIView *upLoadView;
@property (nonatomic, retain) IBOutlet UIImageView *capturedImageV;

@property (nonatomic, retain) IBOutlet UIView *buttonView;
@property (nonatomic, retain) IBOutlet MyButton *btnSubumit;
@property (nonatomic, retain) IBOutlet MyButton *btnCancel;


@property (nonatomic, retain) IBOutlet UILabel *apertureL;
@property (nonatomic, retain) IBOutlet UILabel *shutterL;
@property (nonatomic, retain) IBOutlet UILabel *fStopL;
@property (nonatomic, retain) IBOutlet UILabel *ISOL;
@property (nonatomic, retain) IBOutlet UILabel *brightL;
@property (nonatomic, retain) IBOutlet UserRateView *ratingView;

-(IBAction)getBrightVauleFromWeb:(id)sender;
-(IBAction)checkImageDone:(id)sender;
-(IBAction)btnSubmitInfo:(id)sender;
-(void)initRatingView:(UserRateView *)rateView;
@end


@protocol CheckingImageControllerDelegate

-(void)checkDone:(id)para;

@end