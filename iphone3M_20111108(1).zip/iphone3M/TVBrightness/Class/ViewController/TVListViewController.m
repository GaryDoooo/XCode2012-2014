//
//  TVListViewController.m
//  HDTVBrightness
//
//  Created by zhang on 5/27/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TVListViewController.h"
#import "FileManagerController.h"


@implementation TVListViewController
@synthesize tabTVList,tabModelNumberList,AppCell,TVListSearchBar,NavBar,BackNavBar;
@synthesize ActivityView,TVPickView,SearchBar;
@synthesize Lab;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"bg.png"]];
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
     //[BrandView release];
    [SearchSheet release];
    [arrayModelNumber release];
    [DetailView release];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - button action
-(void)btnBack:(id)sender
{
    BackNavBar.hidden=YES;
    NavBar.hidden=NO;
    tabTVList.hidden=NO;
    SearchBar.hidden=YES;
    Lab.hidden=YES;
    [SearchBar resignFirstResponder];
    [TVPickView removeFromSuperview];
    [tabModelNumberList removeFromSuperview];
}

-(void)btnSearch:(id)sender
{

//    DetailViewController * DetailView=[[DetailViewController alloc]initWithNibName:@"DetailViewController" bundle:nil ];
//    [self.view addSubview:DetailView.view];
    BackNavBar.hidden=NO;
    NavBar.hidden=YES;
    
    [SearchSheet showFromBarButtonItem: NavBar.topItem.leftBarButtonItem animated:YES];
}


-(void)btnAngle:(id)sender
{
    [self ListSortByAngle:1];
}

-(void)btnBrightness:(id)sender
{
    [self ListSortByBrightness:1];
}

-(void)btnEnergy:(id)sender
{
    [self ListSortByEnergy:1];
}



#pragma mark - http request

-(void)TVListRequest:(NSInteger)Page
{
    [self.view addSubview:ActivityView];
    self.view.userInteractionEnabled=NO;
    
    NSString *strPage=[NSString stringWithFormat:@"%d",Page];
    responseData = [[NSMutableData data] retain];
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@/threem/service/clientservices/items/%@/10",ServerAdress,strPage]]];
    
    [request setHTTPMethod:@"POST"];
    NSDictionary *dictJsonHead=[NSDictionary dictionaryWithObject:@"application/json" forKey:@"Content-Type"];
    [request setAllHTTPHeaderFields:dictJsonHead];
    [NSURLConnection connectionWithRequest: request
                                  delegate: self];
}


-(void)ModelNumberListRequestByBrand:(NSString *)brand
{
    [self.view addSubview:ActivityView];
    self.view.userInteractionEnabled=NO;
    responseData = [[NSMutableData data] retain];
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@/threem/service/clientservices/items/b/%@/",ServerAdress,brand]]];
    [request setHTTPMethod:@"POST"];
    NSDictionary *dictJsonHead=[NSDictionary dictionaryWithObject:@"application/json" forKey:@"Content-Type"];
    [request setAllHTTPHeaderFields:dictJsonHead];
    [NSURLConnection connectionWithRequest: request
                                  delegate: self];
}

-(void)ModelNumberListRequestByInch:(NSString *)inch
{
    [self.view addSubview:ActivityView];
    self.view.userInteractionEnabled=NO;
    responseData = [[NSMutableData data] retain];
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@/threem/service/clientservices/items/i/%@",ServerAdress,inch]]];
    [request setHTTPMethod:@"POST"];
    NSDictionary *dictJsonHead=[NSDictionary dictionaryWithObject:@"application/json" forKey:@"Content-Type"];
    [request setAllHTTPHeaderFields:dictJsonHead];
    [NSURLConnection connectionWithRequest: request
                                  delegate: self];
}

-(void)ListSortByBrightness:(NSInteger)Page
{
    [self.view addSubview:ActivityView];
    self.view.userInteractionEnabled=NO;
    responseData = [[NSMutableData data] retain];
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@/threem/service/clientservices/items/%d/10/Bri/",ServerAdress,Page]]];
    [request setHTTPMethod:@"POST"];
    NSDictionary *dictJsonHead=[NSDictionary dictionaryWithObject:@"application/json" forKey:@"Content-Type"];
    [request setAllHTTPHeaderFields:dictJsonHead];
    [NSURLConnection connectionWithRequest: request
                                  delegate: self];
}

-(void)ListSortByAngle:(NSInteger)Page
{
    [self.view addSubview:ActivityView];
    self.view.userInteractionEnabled=NO;
    responseData = [[NSMutableData data] retain];
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@/threem/service/clientservices/items/%d/10/Angle/",ServerAdress,Page]]];
    [request setHTTPMethod:@"POST"];
    NSDictionary *dictJsonHead=[NSDictionary dictionaryWithObject:@"application/json" forKey:@"Content-Type"];
    [request setAllHTTPHeaderFields:dictJsonHead];
    [NSURLConnection connectionWithRequest: request
                                  delegate: self];

}

-(void)ListSortByEnergy:(NSInteger)Page
{
    [self.view addSubview:ActivityView];
    self.view.userInteractionEnabled=NO;
    responseData = [[NSMutableData data] retain];
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@/threem/service/clientservices/items/%d/10/Eff/",ServerAdress,Page]]];
    [request setHTTPMethod:@"POST"];
    NSDictionary *dictJsonHead=[NSDictionary dictionaryWithObject:@"application/json" forKey:@"Content-Type"];
    [request setAllHTTPHeaderFields:dictJsonHead];
    [NSURLConnection connectionWithRequest: request
                                  delegate: self];

}

-(void)SingleNumber:(NSString *)strModelNumber
{
    [self.view addSubview:ActivityView];
    self.view.userInteractionEnabled=NO;
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@/threem/service/clientservices/item/single/%@",ServerAdress,strModelNumber]]];
    [request setHTTPMethod:@"POST"];
    NSDictionary *dictJsonHead=[NSDictionary dictionaryWithObject:@"application/json" forKey:@"Content-Type"];
    [request setAllHTTPHeaderFields:dictJsonHead];
    [NSURLConnection connectionWithRequest: request
                                  delegate: self];

}

#pragma mark - View lifecycle


-(void)initSearchView
{
    SearchBar.delegate=self;
    SearchBar.frame=CGRectMake(0, 44, 320, 44);
    SearchBar.tintColor=[UIColor colorWithRed:0.97 green:0.59 blue:0.14 alpha:1.00];
    [self.view addSubview:SearchBar];
    SearchBar.hidden=YES;
    
    Lab.frame=CGRectMake(0, 88, 320, 44);
     [self.view addSubview:Lab];
    Lab.hidden=YES;
}

-(void)initModelNumberTableView
{
    tabModelNumberList.frame=CGRectMake(0, 205, 320, 210);
    tabModelNumberList.delegate=self;
    tabModelNumberList.dataSource=self;
}

-(void)initPickView
{
    selected=0;
    TVPickView.frame=CGRectMake(0, 44, 320, 150);
    TVPickView.showsSelectionIndicator = YES;
    [TVPickView setBackgroundColor:[UIColor clearColor]];
    TVPickView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    TVPickView.delegate=self; 

    NSString *strBrandListPath=[[FileManagerController resourcePath]stringByAppendingPathComponent:@"TVBrandItem.plist"];
    dictBrandList=[[NSDictionary alloc]initWithContentsOfFile:strBrandListPath];
    if (dictBrandList) {
        
    }
    else
    {
        NSLog(@"找不到品牌列表！");
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"找不到品牌列表"
                                                            message:@"点击确定继续"
                                                           delegate:nil
                                                  cancelButtonTitle:@"确定"
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release];
    }
    
    NSString *strInchListPath=[[FileManagerController resourcePath]stringByAppendingPathComponent:@"TVInchItem.plist"];
    dictInchList=[[NSDictionary alloc]initWithContentsOfFile:strInchListPath];
    
    if (dictInchList) {
        
    }
    else
    {
        NSLog(@"找不到尺寸列表！");
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"找不到尺寸列表"
                                                            message:@"点击确定继续"
                                                           delegate:nil
                                                  cancelButtonTitle:@"确定"
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release];
    }

}

-(void)initNavBar
{
   
    TVListSearchBar.tintColor=[UIColor colorWithRed:0.97 green:0.59 blue:0.14 alpha:1.00];
    NavBar.tintColor=[UIColor colorWithRed:0.97 green:0.59 blue:0.14 alpha:1.00];
    
    UIToolbar* tools = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 165, 44.1)];
    tools.tintColor=[UIColor colorWithRed:0.97 green:0.59 blue:0.14 alpha:1.00];
    NSMutableArray* buttons = [[NSMutableArray alloc] initWithCapacity:3];
    
    //Search button
    UIBarButtonItem* SearchButton = [[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"Search.png"] style:UIBarButtonItemStyleBordered target:self action:@selector(btnSearch:)]autorelease];
    NavBar.topItem.leftBarButtonItem=SearchButton; 
    
    //button Brightness
    UIBarButtonItem* button1 = [[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"Brightness_icon.png"] style:(UIBarButtonItemStyleBordered) target:self action:@selector(btnBrightness:)]autorelease];
    [buttons addObject:button1];
    
    //button Angle
    UIBarButtonItem* button2 = [[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"Angle_icon.png"] style:(UIBarButtonItemStyleBordered) target:self action:@selector(btnAngle:)]autorelease];
    [buttons addObject:button2];
    
    //button Energy
    UIBarButtonItem* button3 = [[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"Energy_icon.png"] style:(UIBarButtonItemStyleBordered) target:self action:@selector(btnEnergy:)]autorelease];
    [buttons addObject:button3];
    
    [tools setItems:buttons animated:NO];
    UIBarButtonItem *rightItem=[[UIBarButtonItem alloc] initWithCustomView:tools];
    NavBar.topItem.rightBarButtonItem = rightItem;
    [rightItem release];
    

    
    //Back Nav Bar initialize 
    BackNavBar.tintColor=[UIColor colorWithRed:0.97 green:0.59 blue:0.14 alpha:1.00];
    //UIButton *back =[[UIButton alloc] initWithFrame:CGRectMake(0, 0, 63, 30)]; 
    UIButton *back = [UIButton buttonWithType:UIButtonTypeCustom];  
    back.frame = CGRectMake(0.0, 0.0, 55, 30);  
    [back addTarget:self action:@selector(btnBack:) forControlEvents:UIControlEventTouchUpInside];
    [back setImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    UIBarButtonItem *backButtonItem = [[UIBarButtonItem alloc] initWithCustomView:back];
    
    BackNavBar.topItem.leftBarButtonItem = backButtonItem;
   // [back release];
    [backButtonItem release];
    [buttons release];
    [tools release];
    //hide in search page and set unhide
    BackNavBar.hidden=YES;
}

-(void)initTableHeadView
{
    _refreshHeaderView = [[EGORefreshTableHeaderView alloc] initWithFrame: CGRectMake(0.0f, self.tabTVList.contentSize.height, 320, 100)];
    _refreshHeaderView.delegate = self;
	[self.tabTVList addSubview:_refreshHeaderView];	
    [_refreshHeaderView refreshLastUpdatedDate];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    tabTVList.delegate=self;
    tabTVList.dataSource=self;
    //strPageCount=[[NSString alloc ]initWithString:@"1"];
    [self initNavBar];
    [self initPickView];
    [self initModelNumberTableView];
    [self initTableHeadView];
    [self initSearchView];
    SearchSheet=[[UIActionSheet alloc]initWithTitle:@"选择搜索方式" delegate:self cancelButtonTitle:nil destructiveButtonTitle:@"按品牌/尺寸搜索" otherButtonTitles:@"普通搜索", @"取消",nil];
    
    arrayDetailList=[[NSMutableArray alloc]init];
    DetailView=[[DetailViewController alloc]initWithNibName:@"DetailViewController" bundle:nil];
    ActivityView.frame=CGRectMake(141, 212, 37, 37);
    _reloading=NO;
    //检测网络是否工作
    if([Reachability reachabilityForInternetConnection])
    {
        //发送TV列表请求
        [self TVListRequest:1];
    }
    else
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"无法连接到网络"
                                                            message:@"点击确定继续"
                                                           delegate:nil
                                                  cancelButtonTitle:@"确定"
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release];
        
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark UIScrollViewDelegate Methods

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{	
	
	[_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
    
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
	
	[_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
	
}


#pragma mark -
#pragma mark Data Source Loading / Reloading Methods

- (void)reloadTableViewDataSource
{
	if ([strCurrentRequest isEqualToString:@"Brightness"]) 
    {
        [self ListSortByBrightness:[strPageCount intValue]+1];
    }	
	else if([strCurrentRequest isEqualToString:@"Angle"])
    {
        [self ListSortByAngle:[strPageCount intValue]+1];
    }
    else if([strCurrentRequest isEqualToString:@"Energy"])
    {
        [self ListSortByEnergy:[strPageCount intValue]+1];
    }
    else
    {
        [self TVListRequest:[strPageCount intValue]+1];
    }
    _reloading=YES;
}

- (void)doneLoadingTableViewData{
	
	//  model should call this when its done loading
	//_reloading = NO;
	[_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tabTVList];
    
	
}

#pragma mark -
#pragma mark EGORefreshTableHeaderDelegate Methods

- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView*)view{
	
	[self reloadTableViewDataSource];
	[self performSelector:@selector(doneLoadingTableViewData) withObject:nil afterDelay:1.5];
	
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView*)view{
	
	return _reloading; // should return if data source model is reloading
	
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView*)view{
	
	return [NSDate date]; // should return date data source was last changed
	
}

#pragma mark - SearchBar delegate
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    //NSLog(@"%@",searchBar.text);
    [self SingleNumber:searchBar.text];
    [SearchBar resignFirstResponder];
}

#pragma mark - PickerView delegate

- (void)selectRow:(NSInteger)row inComponent:(NSInteger)component animated:(BOOL)animated{
    return;
}

//设置列数
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)thePickerView {    
    return 2;
}

//返回数组总数
- (NSInteger)pickerView:(UIPickerView *)thePickerView numberOfRowsInComponent:(NSInteger)component { 
    if(0==component)
        return 2;
    else
    {
        if(0==selected)
            return [[dictBrandList objectForKey:@"Brand"]count];
        else
            return [[dictInchList objectForKey:@"Inch"]count];
    }
}

- (NSString *)pickerView:(UIPickerView *)thePickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (0==component) {
        if (0==row) 
            return @"按品牌";
        else
             return @"按尺寸";
    }
    else
    {
        if(0==selected)
            return [[dictBrandList objectForKey:@"Brand"]objectAtIndex:row];
        else
            return [[dictInchList objectForKey:@"Inch"]objectAtIndex:row];
    }
    
}

//触发事件
- (void)pickerView:(UIPickerView *)thePickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component 
{
    if (0==component) {
        switch (row) 
        {
            case 0:
                selected=0;
                break;
            case 1:
                selected=1;
                break; 
        }
        [TVPickView reloadComponent:1];
    }
    else
    {
        if (0==selected) 
        {
            NSString *strBrand=[[dictBrandList objectForKey:@"Brand"]objectAtIndex:row];
            [self ModelNumberListRequestByBrand:strBrand];
        }
        else
        {
            NSString *strInch=[[dictInchList objectForKey:@"Inch"]objectAtIndex:row];
            [self ModelNumberListRequestByInch:strInch];
        }
    }
}

#pragma mark - ActionSheet Delegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
            tabTVList.hidden=YES;
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:0.4];
            [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
            [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:TVPickView cache:YES];
            [self.view addSubview:TVPickView];
            [UIView commitAnimations];
            
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:0.4];
            [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
            [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:tabModelNumberList cache:YES];
            [self.view addSubview:tabModelNumberList];
            [UIView commitAnimations];
            break;
        case 1:    
            tabTVList.hidden=YES;
            SearchBar.hidden=NO;
            Lab.hidden=NO;
            break;
        case 2:
            [actionSheet dismissWithClickedButtonIndex:buttonIndex animated:YES];
            BackNavBar.hidden=YES;
            NavBar.hidden=NO;
            break;
        default:
            break;
    }
}

- (void)actionSheetCancel:(UIActionSheet *)actionSheet
{
    //remove action sheet
    tabTVList.hidden=NO;
}



#pragma mark - TableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(tabModelNumberList==tableView)
    {
        if (arrayModelNumber) 
            return [arrayModelNumber count];
       else
           return 0;//[arrayDetailList count];;
    }   
    else
    {
        if (arrayDetailList) 
            return [arrayDetailList count];
        else
            return 0;
    }
}	




- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tabModelNumberList==tableView) {
        static NSString *CellIdentifier = @"Cell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
        }
        cell.selectedBackgroundView = [[[UIView alloc] initWithFrame:cell.frame] autorelease];
        cell.selectedBackgroundView.backgroundColor = [UIColor orangeColor];
        cell.textLabel.textColor=[UIColor whiteColor];
        cell.textLabel.text=[arrayModelNumber objectAtIndex:[indexPath row]];
        cell.backgroundColor=[UIColor clearColor];
        UIImageView *backgroundView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"img_listbg_s.png"]];
        cell.backgroundView=backgroundView;
        [backgroundView release];
       
        return cell;
    }
	else
    {
        static NSString *CellIdentifier = @"ApplicationCell";
        ApplicationCell *cell = (ApplicationCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        
        if (cell == nil)
        {
            [[NSBundle mainBundle] loadNibNamed:@"IndividualSubviewsBasedApplicationCell" owner:self options:nil];
            cell = AppCell;
            self.AppCell = nil;
        }
        cell.selectedBackgroundView = [[[UIView alloc] initWithFrame:cell.frame] autorelease];
        cell.selectedBackgroundView.backgroundColor = [UIColor orangeColor];
        cell.useDarkBackground =YES;
        cell.backgroundColor=[UIColor clearColor];
        cell.backgroundView= [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"img_listbg_s.png"]] autorelease];
        NSString *strIconName=[NSString stringWithFormat:@"%d.jpg",([indexPath row]+1)%23];
        
        cell.icon=[UIImage imageNamed:strIconName];
        cell.name=[[arrayDetailList objectAtIndex:[indexPath row]]objectForKey:@"型号"];
        cell.publisher=[[arrayDetailList objectAtIndex:[indexPath row]]objectForKey:@"商标"];
        cell.rating=[[[arrayDetailList objectAtIndex:[indexPath row]]objectForKey:@"brightness"]intValue];
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tabModelNumberList==tableView) {
        //Send single number search request
        [self SingleNumber:[arrayModelNumber objectAtIndex:[indexPath row]]];
    }
    else
    {
        //DetailView=[[DetailViewController alloc]initWithNibName:@"DetailViewController" bundle:nil 
        [DetailView TVInfoTransmit:[arrayDetailList objectAtIndex:[indexPath row]]];
        [self.view addSubview:DetailView.view];
    }
}


-(CGFloat)tableView:(UITableView*)tableView  heightForRowAtIndexPath:(NSIndexPath*) indexPath
{	
    if (tabModelNumberList==tableView) {
        return 40;
    }
    else
    {
        return 73;
    }
}

#pragma mark -
#pragma mark HTTP request delegate


- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
 
	[responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    NSString *receiveString =[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    //NSLog(@"%@",receiveString);
	[responseData appendData:data];
    [receiveString release];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"请求超时！"
                                                        message:@"网络无应答."//[error localizedDescription]
                                                       delegate:nil
                                              cancelButtonTitle:@"确定"
                                              otherButtonTitles:nil];
    [alertView show];
    [alertView release];
    [ActivityView removeFromSuperview];
    self.view.userInteractionEnabled=YES;
}


-(void)DownloadPng:(NSArray *)arrayAppList WithIndex:(NSInteger)index
{
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {

    self.view.userInteractionEnabled=YES;
    NSString *responseString = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
    NSDictionary *dictValue=[responseString JSONValue];
    
    //NSLog(@"%@",dictValue);
    [responseString release];
    //if receive data isn't empty
    if (dictValue) {
        if(1==[[dictValue objectForKey:@"status"]intValue])
        {
            //if status is correct，remove ActivityView
            [ActivityView removeFromSuperview];
            //which request 
            if ((![[dictValue objectForKey:@"stag"]hasPrefix:@"items/b/"]) &&(![[dictValue objectForKey:@"stag"]hasPrefix:@"items/i/"])&&(![[dictValue objectForKey:@"stag"]hasPrefix:@"item/single/"]))
            {
                [arrayDetailList addObjectsFromArray:[[dictValue objectForKey:@"Message"]retain]];
                [tabTVList reloadData];
                _reloading=NO;
                _refreshHeaderView.frame=CGRectMake(0.0f, self.tabTVList.contentSize.height, 320, 80);

                NSRange rangeTemp1=[[dictValue objectForKey:@"stag"]rangeOfString:@"items/"];
                NSRange rangeTemp2=[[dictValue objectForKey:@"stag"]rangeOfString:@"}/10"];
                NSRange rangePageNumber;
                rangePageNumber.location=rangeTemp1.length;
                rangePageNumber.length=rangeTemp2.location-rangeTemp1.length;
                strPageCount=[[[dictValue objectForKey:@"stag"]substringWithRange:rangePageNumber]retain];
                if (1==[strPageCount intValue]) {
                    [arrayDetailList removeAllObjects];
                    [arrayDetailList addObjectsFromArray:[[dictValue objectForKey:@"Message"]retain]];
                    [tabTVList reloadData];
                    _reloading=NO;
                    _refreshHeaderView.frame=CGRectMake(0.0f, self.tabTVList.contentSize.height, 320, 80);
                }
                
                if([[dictValue objectForKey:@"stag"]hasSuffix:@"Bri"])
                    strCurrentRequest=[NSString stringWithString:@"Brightness"];
                else if([[dictValue objectForKey:@"stag"]hasSuffix:@"Angle"])
                    strCurrentRequest=[NSString stringWithString:@"Angle"];
                else if([[dictValue objectForKey:@"stag"]hasSuffix:@"Eff"])
                    strCurrentRequest=[NSString stringWithString:@"Energy"];
                else
                    strCurrentRequest=[NSString stringWithString:@"All"];
            }
            
            else if ([[dictValue objectForKey:@"stag"]hasPrefix:@"items/i/"]) {
                arrayModelNumber=[[dictValue objectForKey:@"Message"]retain];
                if ([arrayModelNumber count]) {
                    [tabModelNumberList reloadData];
                }
            }
            
            else if ([[dictValue objectForKey:@"stag"]hasPrefix:@"items/b/"]){
                arrayModelNumber=[[dictValue objectForKey:@"Message"]retain];
                if ([arrayModelNumber count]) {
                    [tabModelNumberList reloadData];
                }
            }
            else if([[dictValue objectForKey:@"stag"]hasPrefix:@"item/single/"])
            {
                //if single model number search
                //NSLog(@"%@",[[dictValue objectForKey:@"Message"]objectAtIndex:0]);
                [DetailView TVInfoTransmit:[[dictValue objectForKey:@"Message"]objectAtIndex:0]];
                [self.view addSubview:DetailView.view];
            }
            else
            {
                //Do nothing
                NSLog(@"stag 返回字段异常！");
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"stag 返回字段异常"
                                                                    message:@"点击确定继续"
                                                                   delegate:nil
                                                          cancelButtonTitle:@"确定"
                                                          otherButtonTitles:nil];
                [alertView show];
                [alertView release];
                
            }
        }
        else
        {
            //Do something here
            NSLog(@"获取数据失败!");
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"获取数据失败!"
                                                                message:nil
                                                               delegate:nil
                                                      cancelButtonTitle:@"确定"
                                                      otherButtonTitles:nil];
            [alertView show];
            [alertView release];
            [ActivityView removeFromSuperview];
        }
    }
    else
    {
        //Do something here
        NSLog(@"获取数据失败！");
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"获取数据失败!"
                                                            message:nil
                                                           delegate:nil
                                                  cancelButtonTitle:@"确定"
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release];
        [ActivityView removeFromSuperview];
    }

}


@end
