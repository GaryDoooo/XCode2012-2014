//
//  DirectionViewController.m
//  TVBrightness
//
//  Created by zhang on 10/20/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "DirectionViewController.h"

@implementation DirectionViewController
@synthesize imageView;

@synthesize btnClose;

- (id)initWithPageNumber:(int)page
{
    if ((self=[super initWithNibName:@"DirectionViewController" bundle:nil]))
    {
        
        pageNumber = page;
    }
    return self;
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}
#pragma mark - Button action
-(IBAction)ActionClose:(id)sender{
    
    self.view.hidden=YES;

}



#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    switch (pageNumber) {
        case 0:
            imageView.image=[UIImage imageNamed:@"slide1.png"];
            break;
        case 1:
            imageView.image=[UIImage imageNamed:@"slide4.png"];
            break;
        case 2:
             imageView.image=[UIImage imageNamed:@"slide2.jpg"];
            break;
        case 3:
             imageView.image=[UIImage imageNamed:@"slide3.png"];
            break;
        default:
            break;
    }
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
