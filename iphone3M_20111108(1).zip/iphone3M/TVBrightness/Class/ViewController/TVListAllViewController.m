//
//  TVListAllViewController.m
//  TVBrightness
//
//  Created by zhang on 6/18/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TVListAllViewController.h"


@implementation TVListAllViewController

@synthesize AppCell,tabAllTVList;
@synthesize NavBar,SearchBar;

#define strIPAddress @"16.187.55.11:8080"


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil withString:(NSString *)string
{
    self=[super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    arrayListWithBrand=[[[NSMutableArray alloc]init]retain];
    //arrayDisplay=[[NSMutableArray alloc]init];
    if (self)//[self initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) 
    {
        NSString *strPath=[[FileManagerController resourcePath]stringByAppendingPathComponent:@"TVList.plist"];
        NSDictionary *dictPlist=[[NSDictionary alloc]initWithContentsOfFile:strPath];
        strBrand=string;
        if ([string isEqualToString:@"All"]) {
            //TODO
            arrayList=[[NSMutableArray alloc]initWithArray:[dictPlist objectForKey:@"New item"]];

        }
        else if([string isEqualToString:@"Topten"]){
            //TODO
             arrayList=[[NSMutableArray alloc]initWithArray:[dictPlist objectForKey:@"New item"]];
            [self btnRating:nil];
        }
        else{
            //TODO
            arrayList=[[NSMutableArray alloc]initWithArray:[dictPlist objectForKey:@"New item"]];
            for (NSDictionary *dictionary in arrayList) {
               if( [[dictionary objectForKey:@"Brand"]isEqualToString:string])
               {
                   [arrayListWithBrand addObject:dictionary];
               }               
            }
                     }
        [dictPlist release];
        [arrayListWithBrand release];
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - Button Action
-(void)btnBack:(id)sender
{
    [self.view removeFromSuperview];
}

-(void)btnBrightness:(id)sender
{
    NSSortDescriptor *sortDescriptor;
    sortDescriptor = [[[NSSortDescriptor alloc] initWithKey:@"Brightness"
                                                  ascending:YES] autorelease];
    NSSortDescriptor *reversedSortDescriptor=[sortDescriptor reversedSortDescriptor];
    NSArray *sortDescriptors = [NSArray arrayWithObject:reversedSortDescriptor];
    //NSArray *sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    NSMutableArray *sortedArray;
     if([strBrand isEqualToString:@"All"]||[strBrand isEqualToString:@"Topten"])
     {
         sortedArray = (NSMutableArray*)[arrayList sortedArrayUsingDescriptors:sortDescriptors];
         [arrayList  setArray:sortedArray];
         [self.tabAllTVList reloadData];
     }
    else
    {
        sortedArray = (NSMutableArray*)[arrayListWithBrand sortedArrayUsingDescriptors:sortDescriptors];
        [arrayListWithBrand setArray:sortedArray];
        [self.tabAllTVList reloadData];
    }
}


-(void)btnAngle:(id)sender
{
    NSSortDescriptor *sortDescriptor;
    sortDescriptor = [[[NSSortDescriptor alloc] initWithKey:@"Angle"
                                                  ascending:YES] autorelease];
    NSSortDescriptor *reversedSortDescriptor=[sortDescriptor reversedSortDescriptor];
    NSArray *sortDescriptors = [NSArray arrayWithObject:reversedSortDescriptor];
    //NSArray *sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    NSMutableArray *sortedArray;
    if([strBrand isEqualToString:@"All"]||[strBrand isEqualToString:@"Topten"])
    {
        sortedArray = (NSMutableArray*)[arrayList sortedArrayUsingDescriptors:sortDescriptors];
        [arrayList  setArray:sortedArray];
        [self.tabAllTVList reloadData];
    }
    else
    {
        sortedArray = (NSMutableArray*)[arrayListWithBrand sortedArrayUsingDescriptors:sortDescriptors];
        [arrayListWithBrand setArray:sortedArray];
        [self.tabAllTVList reloadData];
    }
}

-(void)btnEnergy:(id)sender
{
    NSSortDescriptor *sortDescriptor;
    sortDescriptor = [[[NSSortDescriptor alloc] initWithKey:@"Energy"
                                                  ascending:YES] autorelease];
    NSSortDescriptor *reversedSortDescriptor=[sortDescriptor reversedSortDescriptor];
    NSArray *sortDescriptors = [NSArray arrayWithObject:reversedSortDescriptor];
    //NSArray *sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    NSMutableArray *sortedArray;
    if([strBrand isEqualToString:@"All"]||[strBrand isEqualToString:@"Topten"])
    {
        sortedArray = (NSMutableArray*)[arrayList sortedArrayUsingDescriptors:sortDescriptors];
        [arrayList  setArray:sortedArray];
        [self.tabAllTVList reloadData];
    }
    else
    {
        sortedArray = (NSMutableArray*)[arrayListWithBrand sortedArrayUsingDescriptors:sortDescriptors];
        [arrayListWithBrand setArray:sortedArray];
        [self.tabAllTVList reloadData];
    }
}

-(void)btnRating:(id)sender
{
    NSSortDescriptor *sortDescriptor;
    sortDescriptor = [[[NSSortDescriptor alloc] initWithKey:@"Rating"
                                                  ascending:YES] autorelease];
    NSSortDescriptor *reversedSortDescriptor=[sortDescriptor reversedSortDescriptor];
    NSArray *sortDescriptors = [NSArray arrayWithObject:reversedSortDescriptor];
    
    NSMutableArray *sortedArray;
    
    [self GetTVList];
    if([strBrand isEqualToString:@"Topten"])
    {
        sortedArray = (NSMutableArray*)[arrayList sortedArrayUsingDescriptors:sortDescriptors];
        [arrayList  setArray:sortedArray];
        [self.tabAllTVList reloadData];
    }
    else
    {
        sortedArray = (NSMutableArray*)[arrayListWithBrand sortedArrayUsingDescriptors:sortDescriptors];
        [arrayListWithBrand setArray:sortedArray];
        [self.tabAllTVList reloadData];
    }
}

#pragma mark - View lifecycle
-(void)GetTVList
{
    responseData = [[NSMutableData data] retain];
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@/threem/service/clientservices/item/LE32T30",strIPAddress]]];
    [request setHTTPMethod:@"POST"];
    NSDictionary *dictJsonHead=[NSDictionary dictionaryWithObject:@"application/json" forKey:@"Content-Type"];
    [request setAllHTTPHeaderFields:dictJsonHead];
    [NSURLConnection connectionWithRequest: request
                                  delegate: self];
    
}


-(void)initTableHeadView
{
    if (_refreshHeaderView == nil) {
		
        //self.tabAllTVList.contentSize.height;
		//EGORefreshTableHeaderView *view = [[EGORefreshTableHeaderView alloc] initWithFrame: CGRectMake(0.0f, self.tabAllTVList.contentSize.height, 320, 150)];
        EGORefreshTableHeaderView *view = [[EGORefreshTableHeaderView alloc] initWithFrame: CGRectMake(0.0f, 720, 320, 100)];
        //NSLog(@"%@", NSStringFromCGRect( view.frame ));
		view.delegate = self;
		[self.tabAllTVList addSubview:view];
		_refreshHeaderView = view;
		[view release];
		
	}
	
	//  update the last update date
	[_refreshHeaderView refreshLastUpdatedDate];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"bg.png"]];
   
    //set table view delegate 
    tabAllTVList.delegate=self;
    tabAllTVList.dataSource=self;
    SearchBar.delegate=self;
    
    
    //change bar color
    SearchBar.tintColor=[UIColor colorWithRed:0.97 green:0.59 blue:0.14 alpha:1.00];
    NavBar.tintColor=[UIColor colorWithRed:0.97 green:0.59 blue:0.14 alpha:1.00];
    
    //set custom button width
    UIToolbar* tools = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 160, 44.01)];
    //set button color
    tools.tintColor=[UIColor colorWithRed:0.97 green:0.59 blue:0.14 alpha:1.00];
    NSMutableArray* buttons = [[NSMutableArray alloc] initWithCapacity:3];

    //button Brightness
    UIBarButtonItem* button1 = [[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"Brightness_icon.png"] style:(UIBarButtonItemStyleBordered) target:self action:@selector(btnBrightness:)]autorelease];
    [buttons addObject:button1];
    
    //button Angle
      UIBarButtonItem* button2 = [[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"Angle_icon.png"] style:(UIBarButtonItemStyleBordered) target:self action:@selector(btnAngle:)]autorelease];
    [buttons addObject:button2];
    
    //button Energy
    UIBarButtonItem* button3 = [[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"Energy_icon.png"] style:(UIBarButtonItemStyleBordered) target:self action:@selector(btnEnergy:)]autorelease];
    [buttons addObject:button3];
   
    
    [tools setItems:buttons animated:NO];
    [buttons release];
    
    // and put the toolbar in the nav bar
    NavBar.topItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:tools];
    //[tools release];

    UIButton *back =[[UIButton alloc] initWithFrame:CGRectMake(180, 25, 55, 30)]; 
    [back addTarget:self action:@selector(btnBack:) forControlEvents:UIControlEventTouchUpInside];
    [back setImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    UIBarButtonItem *backButtonItem = [[UIBarButtonItem alloc] initWithCustomView:back];
    //UIBarButtonItem *backButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(btnBack:)];
    NavBar.topItem.leftBarButtonItem = backButtonItem;
    [self GetTVList];
    [self initTableHeadView];
    [back release];
    [backButtonItem release];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark - TableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF contains[cd] %@",self.searchDisplayController.searchBar.text];
    NSMutableArray *arrayKey=[[NSMutableArray alloc]init];
    NSDictionary *dictTemp;

    if([strBrand isEqualToString:@"All"]||[strBrand isEqualToString:@"Topten"])
    {
        for (NSDictionary *dictionary in arrayList) {
            [arrayKey addObject:[dictionary objectForKey:@"ModelNumber"]];
        }
        dictTemp=[[NSDictionary alloc]initWithObjects:arrayList forKeys:arrayKey];
        NSArray * mutablearray =[dictTemp.allKeys  filteredArrayUsingPredicate:predicate];
        
        if (0==[mutablearray count]) {
                arrayDisplay=arrayList;
            /*
            if (nil!=self.searchDisplayController.searchBar.text) {
                UIAlertView *alert = [[UIAlertView alloc]
                                      initWithTitle:@"找不到匹配项！"
                                      message:@""
                                      delegate:nil
                                      cancelButtonTitle:@"确定"
                                      otherButtonTitles:nil];
                [alert show];
                [alert release];

            }*/
        }
        else
        {
            NSMutableArray *arrayTemp = [[[NSMutableArray alloc]init]autorelease];
            for (NSDictionary *dictionary in arrayList) {
                for(int i=0;i<[mutablearray count];i++)
                {
                    if([[dictionary objectForKey:@"ModelNumber"]isEqualToString:[mutablearray objectAtIndex:i]])
                        [arrayTemp addObject:dictionary];
                }
            }
            arrayDisplay=[arrayTemp retain];
        }
    }
    else
    {
        for (NSDictionary *dictionary in arrayListWithBrand) {
            [arrayKey addObject:[dictionary objectForKey:@"ModelNumber"]];
        }
        dictTemp=[[NSDictionary alloc]initWithObjects:arrayListWithBrand forKeys:arrayKey];
        
        NSArray * mutablearray =[dictTemp.allKeys  filteredArrayUsingPredicate:predicate];
        
        //NSLog(@"Temp array=%@",mutablearray);
        if (0==[mutablearray count]) {
            arrayDisplay=arrayListWithBrand;
        }
        else
        {
            NSMutableArray *arrayTemp = [[[NSMutableArray alloc]init]autorelease];
            for (NSDictionary *dictionary in arrayListWithBrand) {
                for(int i=0;i<[mutablearray count];i++)
                {
                    if([[dictionary objectForKey:@"ModelNumber"]isEqualToString:[mutablearray objectAtIndex:i]])
                        [arrayTemp addObject:dictionary];
                }
            }
            arrayDisplay=[arrayTemp retain];
        }
    }
    
    NSInteger ListCount=[arrayDisplay count];
    //[arrayDisplay release];
    [dictTemp release];
    [arrayKey release];
    return ListCount;
    
}	




- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
	
	static NSString *CellIdentifier = @"ApplicationCell";
	ApplicationCell *cell = (ApplicationCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (cell == nil)
	{
		[[NSBundle mainBundle] loadNibNamed:@"IndividualSubviewsBasedApplicationCell" owner:self options:nil];
		cell = AppCell;
		self.AppCell = nil;
	}
    cell.accessoryView.backgroundColor=[UIColor orangeColor];
    cell.selectedBackgroundView = [[[UIView alloc] initWithFrame:cell.frame] autorelease];
    cell.selectedBackgroundView.backgroundColor = [UIColor orangeColor];
    cell.useDarkBackground =YES;
    cell.backgroundColor=[UIColor clearColor];
    
    cell.publisher=[[arrayDisplay objectAtIndex:[indexPath row]]objectForKey:@"Brand"];
    cell.name=[[arrayDisplay objectAtIndex:[indexPath row]]objectForKey:@"ModelNumber"];
    cell.icon=[UIImage imageNamed:@"ico_01.png"];
    cell.rating =[[[arrayDisplay objectAtIndex:[indexPath row]]objectForKey:@"Rating"]floatValue];
    
	return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DetailViewController *DetailView;
//    if([strBrand isEqualToString:@"All"]||[strBrand isEqualToString:@"Topten"])
//    {
//        DetailView=[[[DetailViewController alloc]initWithNibName:@"DetailViewController" bundle:nil withObject:[arrayDisplay objectAtIndex:[indexPath row]]]retain];
//    }
//    else
//    {
        DetailView=[[[DetailViewController alloc]initWithNibName:@"DetailViewController" bundle:nil withObject:[arrayDisplay objectAtIndex:[indexPath row]]]retain];
   // }
    [self.view addSubview:DetailView.view];
    [DetailView release];
}


-(CGFloat)tableView:(UITableView*)table  heightForRowAtIndexPath:(NSIndexPath*) indexPath
{	
	return 73;
}




#pragma mark - Search Bar Delegate
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
   
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
     [self.tabAllTVList reloadData];
}

#pragma mark -
#pragma mark HTTP request delegate


- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	[responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    NSString *receiveString =[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
   // NSLog(@"%@",receiveString);
	[responseData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"请求超时！"
                                                        message:@"网络无应答."//[error localizedDescription]
                                                       delegate:nil
                                              cancelButtonTitle:@"确定"
                                              otherButtonTitles:nil];
    [alertView show];
    [alertView release];
   // [ActivityView removeFromSuperview];
    self.view.userInteractionEnabled=YES;
    
}


-(void)DownloadPng:(NSArray *)arrayAppList WithIndex:(NSInteger)index
{
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    
	NSString *responseString = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
    NSDictionary *dictValue=[responseString JSONValue];
    [responseString release];
    
    if ([[dictValue objectForKey:@"result"]isEqualToString:@"ok"]) 
    {
    
    }
}



#pragma mark - ASYNC HTTP request delegate
- (void)requestFinished:(ASIHTTPRequest *)request
{
    NSData *respData = [request responseData]; 
    
    NSString *strPngName=[NSString stringWithFormat:@"%@",request.originalURL];
    NSRange rangeString = [strPngName rangeOfString:@"/" options:NSBackwardsSearch];
    NSRange rangeTemp;
    rangeTemp.location=rangeString.location+1;
    rangeTemp.length=strPngName.length-rangeString.location-1;
    NSString *strTemp=[strPngName substringWithRange:rangeTemp];
    
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString * Path= [NSString stringWithFormat:@"%@/%@", documentsDirectory,strTemp];
    [respData writeToFile:Path atomically:YES];
   // [tableview reloadData];
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSError *error = [request error];
    NSLog(@"%@",error);
}


#pragma mark -
#pragma mark Data Source Loading / Reloading Methods

- (void)reloadTableViewDataSource{
	
	//  should be calling your tableviews data source model to reload
	//  put here just for demo
	//_reloading = YES;
	
}

- (void)doneLoadingTableViewData{
	
	//  model should call this when its done loading
	//_reloading = NO;
	[_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tabAllTVList];
	
}


#pragma mark -
#pragma mark UIScrollViewDelegate Methods

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{	
	
	[_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
    
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
	
	[_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
	
}


#pragma mark -
#pragma mark EGORefreshTableHeaderDelegate Methods

- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView*)view{
	
	[self reloadTableViewDataSource];
	[self performSelector:@selector(doneLoadingTableViewData) withObject:nil afterDelay:4.0];
	
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView*)view{
	
	return _reloading; // should return if data source model is reloading
	
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView*)view{
	
	return [NSDate date]; // should return date data source was last changed
	
}


@end
