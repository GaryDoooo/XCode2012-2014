//
//  define.h
//  TVBrightness
//
//  Created by zhang on 8/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Reachability.h"
#import "EGORefreshTableHeaderView.h"
#import "ApplicationCell.h"
#import "IndividualSubviewsBasedApplicationCell.h"
#import "NSObject+SBJson.h"
#import "MyButton.h"

#import "DetailViewController.h"
#import "PageContentViewController.h"
#import "DirectionViewController.h"
#import "MyButton.h"

#define DEFAULT_ROW_HEIGHT 140
#define HEADER_HEIGHT 40
#define kNumberOfPages 3
#define kNumberOfPages_DirectionView 4
//hp server address
//#define ServerAdress @"116.247.118.250:28008"

#define ServerAdress @"114.80.200.43:8080"
