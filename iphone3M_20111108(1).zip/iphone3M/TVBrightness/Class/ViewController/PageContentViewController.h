//
//  PageContentViewController.h
//  TVBrightness
//
//  Created by zhang on 9/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PageContentViewController : UIViewController {
    UITextView *TextView;
    UILabel *labTitle;
    NSInteger pageNumber;
    UIPageControl *PageControl;
    
}

@property(nonatomic,retain) IBOutlet UITextView *TextView;
@property(nonatomic,retain) IBOutlet UILabel *labTitle;
@property(nonatomic,retain) IBOutlet UIPageControl *PageControl;
- (id)initWithPageNumber:(int)page;
@end
