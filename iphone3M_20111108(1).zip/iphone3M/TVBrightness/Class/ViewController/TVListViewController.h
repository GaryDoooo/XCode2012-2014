//
//  TVListViewController.h
//  HDTVBrightness
//
//  Created by zhang on 5/27/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ApplicationCell.h"
#import "DetailViewController.h"
#import "TVListAllViewController.h"
#import "define.h"


@interface TVListViewController : UIViewController <UITableViewDelegate,UITableViewDataSource,UIActionSheetDelegate,UISearchBarDelegate,UIPickerViewDelegate,EGORefreshTableHeaderDelegate>{
    UITableView *tabTVList;
    UITableView *tabModelNumberList;
    ApplicationCell *AppCell;
    
    NSArray *arrayList;
    NSArray *arrayBrandList;
    UISearchBar *TVListSearchBar;
    UINavigationBar *NavBar;
    UINavigationBar *BackNavBar;
    EGORefreshTableHeaderView *_refreshHeaderView;
    NSMutableData *responseData;
    UIView *ActivityView;
    UIPickerView *TVPickView;
    
    NSDictionary *dictBrandList;
    NSDictionary *dictInchList;
    NSInteger selected;
    NSArray *arrayModelNumber;
    NSMutableArray *arrayDetailList;
    NSString *strPageCount;
    NSString *strCurrentRequest;
    BOOL  _reloading;
    DetailViewController *DetailView;
    UIActionSheet *SearchSheet;
    UISearchBar *SearchBar;
}

@property(nonatomic,retain)IBOutlet UITableView *tabTVList;
@property(nonatomic,retain)IBOutlet  UITableView *tabModelNumberList;
@property(nonatomic,retain)IBOutlet ApplicationCell *AppCell;
@property(nonatomic,retain)IBOutlet UISearchBar *TVListSearchBar;
@property(nonatomic,retain)IBOutlet UINavigationBar *NavBar;
@property(nonatomic,retain)IBOutlet UINavigationBar *BackNavBar;
@property(nonatomic,retain)IBOutlet UIView *ActivityView;
@property(nonatomic,retain)IBOutlet UIPickerView *TVPickView;
@property(nonatomic,retain)IBOutlet UISearchBar *SearchBar;
@property(nonatomic,retain)IBOutlet UILabel *Lab;

-(void)ListSortByAngle:(NSInteger)Page;
-(void)ListSortByEnergy:(NSInteger)Page;
-(void)ListSortByBrightness:(NSInteger)Page;
@end
