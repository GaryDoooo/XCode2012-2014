//
//  UserGuideViewController.h
//  TVBrightness
//
//  Created by zhang on 10/25/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "define.h"

@interface UserGuideViewController : UIViewController<UIScrollViewDelegate>
{
    
}

@property (nonatomic,retain) IBOutlet UIScrollView *ScrollView;

@end
