//
//  DetailViewController.h
//  TVBrightness
//
//  Created by zhang on 6/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "define.h"



@class QuoteCell;


@interface DetailViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate> {
    UITableView *TableView;
    UINavigationBar *NavBar;
    ApplicationCell *AppCell;
    UIScrollView *ScrollView;
    MyButton *CloseButton;
}

@property (nonatomic, retain) NSDictionary* dictTVinfo;
@property (nonatomic, assign) IBOutlet UITableView *TableView;
@property (nonatomic, retain) IBOutlet ApplicationCell *AppCell;
@property (nonatomic,retain) IBOutlet UIImageView *iconImage;
@property (nonatomic,retain) IBOutlet UINavigationBar *NavBar;
@property (nonatomic,retain) IBOutlet UIScrollView *ScrollView;
@property (nonatomic,retain) IBOutlet MyButton *CloseButton;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil withObject:(NSDictionary *)dictionary;
-(void)TVInfoTransmit:(NSDictionary *)dict;
- (void)loadScrollViewWithPage:(int)page;

-(void)btnClose:(id)sender;
-(int)EnergyCaculate:(int)Power Inch:(int)inch;

@end
