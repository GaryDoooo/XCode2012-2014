//
//  CheckingImageController.m
//  MMM
//
//  Created by Evangel on 11-5-13.
//  Copyright 2011年 Hp. All rights reserved.
//

#import "CheckingImageController.h"


@implementation CheckingImageController

@synthesize upLoadView;
@synthesize capturedImageV,buttonView;
@synthesize delegate;
@synthesize data;
@synthesize btnCancel,btnSubumit;
@synthesize apertureL,shutterL,fStopL,ISOL,brightL;
@synthesize ratingView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
  [data release];
  [upLoadView release];
  [capturedImageV release];
  
  [apertureL release];
  [shutterL release];
  [fStopL release];
  [ISOL release];
  [brightL release];
  [super dealloc];
}

- (void)didReceiveMemoryWarning
{
  [super didReceiveMemoryWarning];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initRatingView:ratingView];
    [ratingView setUserInteractionEnabled:NO];
    //ratingView.rating=3.5;
    self.buttonView.frame=CGRectMake(0, 358, 320, 60);
    
    self.buttonView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"img_blackbg.png"]];
    [self.view addSubview:buttonView];
    CGSize size;
    size.width=145;
    size.height=50;
    [btnSubumit setBackgroundImage:[UIImage imageNamed:@"btn_01.png"] withSize:size ];
    [btnCancel setBackgroundImage:[UIImage imageNamed:@"btn_02.png"] withSize:size ];
    //NSLog(@"data for show:%@",data);
    if(data)
    {
        NSDictionary *dict = [(NSDictionary*)data objectForKey:@"sourceData"];
        self.apertureL.text = [NSString stringWithFormat:@"%.3f",[[dict objectForKey:@"ApertureValue"] floatValue]];
        self.shutterL.text = [NSString stringWithFormat:@"1/%.0fs",1/[[dict objectForKey:@"ExposureTime"] floatValue]];
        self.ISOL.text = [NSString stringWithFormat:@"%.0f",[[[dict objectForKey:@"ISOSpeedRatings"] objectAtIndex:0] floatValue]];
    
      // EV = 3.321Log ((A^2/T )*100/actual ISO)
        float AV=[[dict objectForKey:@"ApertureValue"] floatValue];
        float TV=[[dict objectForKey:@"ExposureTime"] floatValue];
        float ISO=[[[dict objectForKey:@"ISOSpeedRatings"] objectAtIndex:0]intValue];
      
        float EV=3.32*log((AV*AV/TV)*100/ISO);
        self.fStopL.text=[NSString stringWithFormat:@"%.3f", EV];
        [self.capturedImageV setImage:[(NSDictionary*)data objectForKey:@"image"]];
        
        if (EV<16) {
            ratingView.rating=0.5;
        }
        else if((EV>=16)&&(EV<18)){
             ratingView.rating=1.0;
        }
        else if((EV>=18)&&(EV<18.7)){
            ratingView.rating=1.5;
        }
        else if((EV>=18.7)&&(EV<19.4)){
            ratingView.rating=2.0;
        }
        else if((EV>=19.4)&&(EV<20.1)){
            ratingView.rating=2.5;
        }
        else if((EV>=20.1)&&(EV<20.8)){
            ratingView.rating=3.0;
        }
        else if((EV>=20.8)&&(EV<22)){
            ratingView.rating=3.5;
        }
        else if((EV>=22)&&(EV<22.5)){
            ratingView.rating=4.0;
        }
        else if((EV>=22.5)&&(EV<25)){
            ratingView.rating=4.5;
        }
        else if(EV>25){
            ratingView.rating=5.0;
        }
        else{
            ratingView.rating=0.0;
        }
    }
}



- (void)viewDidUnload
{
  self.upLoadView = nil;
  self.capturedImageV = nil;
  self.apertureL = nil;
  self.shutterL = nil;
  self.fStopL = nil;
  self.brightL = nil;
  [super viewDidUnload];
}



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


-(void)initRatingView:(UserRateView *)rateView
{
    rateView.notSelectedImage =[UIImage imageNamed:@"star_0.png"];
    rateView.halfSelectedImage =[UIImage imageNamed:@"star_half.png"];
    rateView.fullSelectedImage =[UIImage imageNamed:@"star_1.png"];
    rateView.rating =0;
    rateView.editable =YES;
    rateView.maxRating =5;
    rateView.delegate = self;
}


#pragma mark - button action
-(IBAction)btnSubmitInfo:(id)sender
{
    [self checkImageDone:nil];
    NSMutableDictionary *userInfo=[[NSMutableDictionary alloc]init];
    [userInfo setObject:[(NSDictionary*)data objectForKey:@"image"] forKey:@"Image"];
    NSString *strRating=[NSString stringWithFormat:@"%.1f",ratingView.rating];
    [userInfo setObject:strRating forKey:@"BrLevel"];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"CallUserCommentsView" object:nil userInfo:userInfo];
    [userInfo release];
    
}

-(IBAction)getBrightVauleFromWeb:(id)sender
{
  //cal metadata of image here,and cal brightness
  if(data)
  {
    
  }
}

-(IBAction)checkImageDone:(id)sender
{
  [UIView animateWithDuration:.4f
                   animations:^{
                     [self.upLoadView setAlpha:1.f];
                     [self.upLoadView setAlpha:0.f];
                   }
                   completion:^(BOOL finished){
                     [self.upLoadView removeFromSuperview];
                   }
   ];
  
  if([(NSObject*)delegate respondsToSelector:@selector(checkDone:)])
  {
    [delegate checkDone:nil];
  }
}

#pragma mark - RatingView delegate
- (void)rateView:(UserRateView *)rateView ratingDidChange:(float)rating {
    //do something here
}

@end
