//
//  UserGuideViewController.m
//  TVBrightness
//
//  Created by zhang on 10/25/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "UserGuideViewController.h"


@implementation UserGuideViewController
@synthesize ScrollView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)scrollViewDidScroll:(UIScrollView *)sender
{
    //    CGFloat pageWidth = ScrollView.frame.size.width;
    //    int page = floor((ScrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    
}

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)newScrollView
{
    //    CGFloat pageWidth = ScrollView.frame.size.width;
    //    float fractionalPage = ScrollView.contentOffset.x / pageWidth;
    //    NSInteger nearestNumber = lround(fractionalPage);
}


#pragma mark - View lifecycle

- (void)loadScrollViewWithPage:(int)page
{
    if (page < 0)
        return;
    if (page >= kNumberOfPages_DirectionView)
        return;
    
    DirectionViewController *Content = [[DirectionViewController alloc] initWithPageNumber:page];
    CGRect frame = ScrollView.frame;
    frame.origin.x = frame.size.width * page;
    frame.origin.y = 0;
    Content.view.frame = frame;
    Content.view.backgroundColor=[UIColor clearColor];
    
    
    
    Content.PageControl.numberOfPages=4;
    Content.PageControl.currentPage=page;
    Content.PageControl.backgroundColor=[UIColor clearColor];
    [ScrollView addSubview:Content.view];
    [Content release];
    
}


-(void)initScrollView
{
    ScrollView.backgroundColor=[UIColor clearColor];
    ScrollView.pagingEnabled = YES;
    ScrollView.contentSize = CGSizeMake(ScrollView.frame.size.width * kNumberOfPages_DirectionView, ScrollView.frame.size.height);
    ScrollView.frame=CGRectMake(0, 20, 320, ScrollView.frame.size.height);
    ScrollView.showsHorizontalScrollIndicator = NO;
    ScrollView.showsVerticalScrollIndicator = NO;
    ScrollView.scrollsToTop = NO;
    ScrollView.delegate = self;
    
    [self loadScrollViewWithPage:0];
    [self loadScrollViewWithPage:1];
    [self loadScrollViewWithPage:2];
    [self loadScrollViewWithPage:3];
    
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initScrollView];
    [self.view addSubview:ScrollView];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
