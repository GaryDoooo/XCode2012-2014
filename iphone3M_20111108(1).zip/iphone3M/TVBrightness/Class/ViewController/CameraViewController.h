//
//  CameraViewController.h
//  HDTVBrightness
//
//  Created by zhang on 5/27/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ImageIO/ImageIO.h>
#import <CoreVideo/CoreVideo.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <CoreVideo/CoreVideo.h>
#import "CheckingImageController.h"
#import "MyButton.h"
#import "CustomUIProgressBar.h"



@interface CameraViewController : UIViewController<AVCaptureVideoDataOutputSampleBufferDelegate,CheckingImageControllerDelegate> {
    AVCaptureSession *captureSession;
    
    // Devic Inputs
    AVCaptureDeviceInput *videoInput;
    // Capture Outputs
    AVCaptureVideoDataOutput *videoOutput;
    AVCaptureStillImageOutput *stillImgOutput;
    
    CALayer *customLayer;
    AVCaptureVideoPreviewLayer *prevLayer;
    UIView * ButtonView;
    MyButton *btnCapture;
    CustomUIProgressBar *ProgressBar;
    //CALayer *ExposeBox;
    UIImageView *imageView;
}

@property (nonatomic,retain) UIImageView *imageView;
@property (nonatomic,retain) CALayer *ExposeBox;
@property (nonatomic,retain) AVCaptureDeviceInput *videoInput;
@property (nonatomic,retain) AVCaptureVideoDataOutput *videoOutput;
@property (nonatomic,retain) AVCaptureStillImageOutput *stillImgOutput;
@property (nonatomic, retain) AVCaptureSession *captureSession;

@property (nonatomic, retain) AVCaptureVideoPreviewLayer *prevLayer;
@property (nonatomic, retain) IBOutlet UILabel *labBrightness;
@property (nonatomic, retain) IBOutlet UILabel *apertureL;
@property (nonatomic, retain) IBOutlet UILabel *shutterL;
@property (nonatomic, retain) IBOutlet UILabel *fStopL;
@property (nonatomic, retain) IBOutlet UILabel *ISOL;
@property (nonatomic, retain) IBOutlet UILabel *brightL;
@property (nonatomic, retain) CustomUIProgressBar *ProgressBar;

@property (nonatomic, retain) IBOutlet  MyButton *btnCapture;
-(IBAction)captureStillImage:(id)sender;



@end
