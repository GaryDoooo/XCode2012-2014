//
//  CameraViewController.m
//  HDTVBrightness
//
//  Created by zhang on 5/27/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CameraViewController.h"


@implementation CameraViewController

@synthesize captureSession ,prevLayer,labBrightness;
@synthesize apertureL,shutterL,fStopL,ISOL,brightL;
@synthesize videoInput;
@synthesize videoOutput;
@synthesize stillImgOutput;
@synthesize btnCapture;
@synthesize ProgressBar;
@synthesize ExposeBox,imageView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [imageView release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)initCapture
{
    //session
    AVCaptureSession *session = [[AVCaptureSession alloc] init];
    self.captureSession = session;
    [session release];
    

    //input
    AVCaptureDeviceInput *captureInput = [[AVCaptureDeviceInput alloc] initWithDevice:[AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo] 
                                                                                error:nil];  
    self.videoInput = captureInput;
    [captureInput release];
    [self.captureSession addInput:self.videoInput];
    
    //output
    AVCaptureVideoDataOutput *captureOutput = [[AVCaptureVideoDataOutput alloc] init];
    captureOutput.alwaysDiscardsLateVideoFrames = YES; 
    
    dispatch_queue_t queue;
    queue = dispatch_queue_create("cameraQueue", NULL);
    [captureOutput setSampleBufferDelegate:self queue:queue];
    dispatch_release(queue);
    
    NSString* key = (NSString*)kCVPixelBufferPixelFormatTypeKey; 
    NSNumber* value = [NSNumber numberWithUnsignedInt:kCVPixelFormatType_32BGRA]; 
    NSDictionary* videoSettings = [NSDictionary dictionaryWithObject:value forKey:key]; 
    [captureOutput setVideoSettings:videoSettings]; 
    self.videoOutput = captureOutput;
    [captureOutput release];
    [self.captureSession addOutput:self.videoOutput];
    
    AVCaptureStillImageOutput *stillImageOutput = [[AVCaptureStillImageOutput alloc] init];
    NSDictionary *outputSettings = [[NSDictionary alloc] initWithObjectsAndKeys:
                                    AVVideoCodecJPEG, AVVideoCodecKey,
                                    nil];
    [stillImageOutput setOutputSettings:outputSettings];
    [outputSettings release];
    
    self.stillImgOutput = stillImageOutput;
    [stillImageOutput release];
    [self.captureSession addOutput:self.stillImgOutput];
    
    
    self.prevLayer = [AVCaptureVideoPreviewLayer layerWithSession: self.captureSession];
    self.prevLayer.frame = CGRectMake(0, 0, 320, 416);
    self.prevLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    [self.view.layer insertSublayer:self.prevLayer below:[[self.view.layer sublayers] objectAtIndex:0]];
     
    if(![self.captureSession isRunning])
        [self.captureSession startRunning];
    
    //init focus frame
    CGPoint CenterPoint;
    CenterPoint.x=160;
    CenterPoint.y=230;
    imageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"focus.png"]];
    imageView.center=CenterPoint;
    [self.view addSubview:imageView];
    //NSLog(@"init complate");
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"调节电视机色度和亮度到最高"
                                                        message:@"-距离电视机1米左右\n-点击屏幕测光\n-点击拍摄按钮获取数据"//[error localizedDescription]
                                                       delegate:nil
                                              cancelButtonTitle:@"确定"
                                              otherButtonTitles:nil];
    [alertView show];
    [alertView release];
    
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        [self initCapture];
        //NSLog(@"view did load");
        CGSize size;
        size.width=87;
        size.height=98;
        [btnCapture setBackgroundImage:[UIImage imageNamed:@"capture.png"] withSize:size ];
    }
    else
    {
        UIImageView *NoCamera = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"Closed.png"]];
        NoCamera.frame = CGRectMake(0, 0, 320, 460);
        [self.view addSubview:NoCamera];
        [NoCamera release];
    }
    
    self.ProgressBar =[[CustomUIProgressBar alloc]initWithFrame:CGRectMake(10, 20,300,20)];
    self.ProgressBar.minValue=1;
    self.ProgressBar.maxValue = 17;
    self.ProgressBar.currentValue = 1;	
    [self.ProgressBar setLineColor:[UIColor whiteColor]];	
    [self.ProgressBar setProgressColor:[UIColor orangeColor]];	
    [self.ProgressBar setProgressRemainingColor:[UIColor clearColor]];
    [self.view addSubview:self.ProgressBar];
    [self.ProgressBar release];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [self.ProgressBar release];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
    
}



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


-(void)updateVideoInfo:(id)data
{
    
//    for (id key in data) {
//        NSLog(@"key = %@, value = %@",key,[data objectForKey:key]);
//    }

    if(data)
    {
        self.apertureL.text = [NSString stringWithFormat:@"%.2f",[[(NSDictionary*)data objectForKey:(NSString*)kCGImagePropertyExifApertureValue] floatValue]];
        self.shutterL.text = [NSString stringWithFormat:@"1/%.0fs",1/[[(NSDictionary*)data objectForKey:(NSString *)kCGImagePropertyExifExposureTime] floatValue]];
        self.ISOL.text = [NSString stringWithFormat:@"%@",[[(NSDictionary*)data objectForKey:(NSString*)kCGImagePropertyExifISOSpeedRatings] objectAtIndex:0]];
        
        // EV = 3.321Log ((A^2/T )*100/actual ISO)
        float AV=[[(NSDictionary*)data objectForKey:(NSString*)kCGImagePropertyExifApertureValue]floatValue];
        float TV=[[(NSDictionary*)data objectForKey:(NSString*)kCGImagePropertyExifExposureTime] floatValue];
        float ISO=[[[(NSDictionary*)data objectForKey:(NSString*)kCGImagePropertyExifISOSpeedRatings]objectAtIndex:0]floatValue];
        
        float EV=3.32*log((AV*AV/TV)*100/ISO);
        
        //NSLog(@"%f",EV);
        
        self.fStopL.text=[NSString stringWithFormat:@"%.3f", EV];
               
        int BrightnessValue = EV-9;
        NSNumber *numBrightness=[NSNumber numberWithInt:BrightnessValue];
        self.ProgressBar.currentValue = [numBrightness intValue];
    }
}


-(void)updateVideoInfo2:(id)data
{
//    for (id key in data) {
//        NSLog(@"key = %@, value = %@",key,[data objectForKey:key]);
//    }
    
    if(data)
    {
        self.apertureL.text = [NSString stringWithFormat:@"%.2f",[[(NSDictionary*)data objectForKey:(NSString*)kCGImagePropertyExifApertureValue] floatValue]];
        self.shutterL.text = [NSString stringWithFormat:@"1/%.0fs",1/[[(NSDictionary*)data objectForKey:(NSString *)kCGImagePropertyExifExposureTime] floatValue]];
        self.ISOL.text = [NSString stringWithFormat:@"%@",[(NSDictionary*)data objectForKey:@"ISOSpeedRating"]];
        
        // EV = 3.321Log ((A^2/T )*100/actual ISO)
        float AV=[[(NSDictionary*)data objectForKey:(NSString*)kCGImagePropertyExifApertureValue]floatValue];
        float TV=[[(NSDictionary*)data objectForKey:(NSString*)kCGImagePropertyExifExposureTime] floatValue];
        float ISO=[[(NSDictionary*)data objectForKey:@"ISOSpeedRating"]floatValue];
        
        float EV=3.32*log((AV*AV/TV)*100/ISO);
        
        //NSLog(@"%f",EV);
        
        self.fStopL.text=[NSString stringWithFormat:@"%.3f", EV];
        
        int BrightnessValue = EV-9;
        NSNumber *numBrightness=[NSNumber numberWithInt:BrightnessValue];
        self.ProgressBar.currentValue = [numBrightness intValue];
    }
}


- (CGImageRef) imageFromSampleBuffer:(CMSampleBufferRef) sampleBuffer // Create a CGImageRef from sample buffer data
{
    CVImageBufferRef imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer); 
    CVPixelBufferLockBaseAddress(imageBuffer,0);        // Lock the image buffer 
    
    uint8_t *baseAddress = (uint8_t *)CVPixelBufferGetBaseAddressOfPlane(imageBuffer, 0);   // Get information of the image 
    size_t bytesPerRow = CVPixelBufferGetBytesPerRow(imageBuffer); 
    size_t width = CVPixelBufferGetWidth(imageBuffer); 
    size_t height = CVPixelBufferGetHeight(imageBuffer); 
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB(); 
    
    CGContextRef newContext = CGBitmapContextCreate(baseAddress, width, height, 8, bytesPerRow, colorSpace, kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedFirst); 
    CGImageRef newImage = CGBitmapContextCreateImage(newContext); 
    CGContextRelease(newContext); 
    
    CGColorSpaceRelease(colorSpace); 
    CVPixelBufferUnlockBaseAddress(imageBuffer,0); 
    /* CVBufferRelease(imageBuffer); */  // do not call this!
    
    return newImage;
}


- (void)processNewCameraFrame:(CVImageBufferRef)cameraFrame;
{
	CVPixelBufferLockBaseAddress(cameraFrame, 0);
    
	NSDictionary    *attachmentValue        = (NSDictionary *)CVBufferGetAttachments(cameraFrame, kCVAttachmentMode_ShouldPropagate);
    NSDictionary *dictMetadata= [attachmentValue objectForKey:@"MetadataDictionary"];
    
    [self performSelectorOnMainThread:@selector(updateVideoInfo2:) withObject:(NSDictionary*)dictMetadata waitUntilDone:YES];
}


- (void)captureOutput:(AVCaptureOutput *)captureOutput 
didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer 
	   fromConnection:(AVCaptureConnection *)connection 
{ 
    NSString *strOSVersion=[UIDevice currentDevice].systemVersion;
    float OSvalue=[strOSVersion floatValue];
    //OS version <= 4.3.2 
    if ((OSvalue<4.3) ||[strOSVersion hasPrefix:@"4.3.1"]||[strOSVersion hasPrefix:@"4.3.2"])
    {
        CVImageBufferRef pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer);
        [self processNewCameraFrame:pixelBuffer];
    }
    //OS version >4.3.3
    else
    {
        CFDictionaryRef exifAttachments = CMGetAttachment(sampleBuffer,kCGImagePropertyExifDictionary,NULL);
        NSMutableDictionary *data = [[NSMutableDictionary alloc] initWithDictionary:(NSDictionary *)exifAttachments];
        [self performSelectorOnMainThread:@selector(updateVideoInfo:) withObject:(NSDictionary*)data waitUntilDone:YES];
        [data release];
    }
    
} 

-(AVCaptureConnection *)connectionWithMediaType:(NSString *)mediaType fromConnections:(NSArray *)connections;
{
    for ( AVCaptureConnection *connection in connections ) {
        for ( AVCaptureInputPort *port in [connection inputPorts] ) {
            if ( [[port mediaType] isEqual:mediaType] ) {
                return [connection retain];
            }
        }
    }
    return nil;
}

- (void) captureStillImageFailedWithError:(NSError *)error
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Still Image Capture Failure"
                                                        message:[error localizedDescription]
                                                       delegate:nil
                                              cancelButtonTitle:@"Okay"
                                              otherButtonTitles:nil];
    [alertView show];
    [alertView release];
}

#pragma mark - Static image

-(void)showImageCheckView:(id)data
{
    NSDictionary *dict = [[NSDictionary alloc] initWithDictionary:(NSDictionary*)data];
    
    if([self.captureSession isRunning])
        [self.captureSession stopRunning];
    
    CheckingImageController *chkC = [[CheckingImageController alloc] initWithNibName:@"CheckingImageController" 
                                                                              bundle:nil];
    chkC.delegate = self;
    chkC.data = data;
    [self presentModalViewController:chkC animated:YES];

    [chkC release];
    [dict release];
}

-(void)newThreadWithData:(id)data
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    [self performSelectorOnMainThread:@selector(showImageCheckView:) withObject:data waitUntilDone:NO];
    
    [pool release];
}

-(IBAction)captureStillImage:(id)sender
{
    AVCaptureConnection *videoConnection = [self connectionWithMediaType:AVMediaTypeVideo 
                                                         fromConnections:self.stillImgOutput.connections];
    
    [self.stillImgOutput captureStillImageAsynchronouslyFromConnection:videoConnection
                                                     completionHandler:^(CMSampleBufferRef imageDataSampleBuffer, NSError *error) 
     {
         if (imageDataSampleBuffer != NULL) 
         { 
             CFDictionaryRef exifAtt = CMGetAttachment(imageDataSampleBuffer, kCGImagePropertyExifDictionary, NULL);
             if(exifAtt)
             {
                 NSMutableDictionary *dataDict = [[NSMutableDictionary alloc] init];
                 
                 NSData *imageData = [AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:imageDataSampleBuffer];
                 UIImage *image = [[UIImage alloc] initWithData:imageData];  
                 
                 [dataDict setObject:(NSDictionary*)exifAtt forKey:@"sourceData"];
                 [dataDict setObject:image forKey:@"image"];
                 
                 [NSThread detachNewThreadSelector:@selector(newThreadWithData:) toTarget:self withObject:dataDict];
                 
                 [image release];
                 [dataDict release];
             }
         } 
         else if (error) 
         {
             [self captureStillImageFailedWithError:error];
         }
     }];
    [videoConnection release];
    
    //flash
    UIView *flashView = [[UIView alloc] initWithFrame:self.view.bounds];
    [flashView setBackgroundColor:[UIColor whiteColor]];
    [flashView setAlpha:0.f];
    [self.view addSubview:flashView];
    
    [UIView animateWithDuration:.7f
                     animations:^{
                         [flashView setAlpha:1.f];
                         [flashView setAlpha:0.f];
                     }
                     completion:^(BOOL finished){
                         [flashView removeFromSuperview];
                         [flashView release];
                     }
     ];
}

#pragma mark - Capture Done
-(void)checkDone:(id)para
{
   if(![self.captureSession isRunning])
        [self.captureSession startRunning];
    
    [self dismissModalViewControllerAnimated:YES];
}

#pragma mark - Tap to focus

+ (void)addAdjustingAnimationToLayer:(CALayer *)layer removeAnimation:(BOOL)remove
{
    if (remove) {
        [layer removeAnimationForKey:@"animateOpacity"];
    }
    if ([layer animationForKey:@"animateOpacity"] == nil) {
        [layer setHidden:NO];
        CABasicAnimation *opacityAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
        [opacityAnimation setDuration:.3f];
        [opacityAnimation setRepeatCount:1.f];
        [opacityAnimation setAutoreverses:YES];
        [opacityAnimation setFromValue:[NSNumber numberWithFloat:1.f]];
        [opacityAnimation setToValue:[NSNumber numberWithFloat:.0f]];
        [layer addAnimation:opacityAnimation forKey:@"animateOpacity"];
    }
}


- (void)drawExposeBoxAtPointOfInterest:(CGPoint)point
{
    imageView.center=point;
}


- (void) focusAtPoint:(CGPoint)point
{
    AVCaptureDevice *device = [[self videoInput] device];
    if ([device isFocusPointOfInterestSupported] && [device isFocusModeSupported:AVCaptureFocusModeAutoFocus]) 
    {
        NSError *error;
        if ([device lockForConfiguration:&error]) {
            [device setFocusPointOfInterest:point];
            [device setFocusMode:AVCaptureFocusModeAutoFocus];
            [device unlockForConfiguration];
        } 
    }
}

- (CGPoint)convertToPointOfInterestFromViewCoordinates:(CGPoint)viewCoordinates 
{
    CGPoint pointOfInterest = CGPointMake(.5f, .5f);
   // CGSize frameSize = self.view.frame.size;
    
    pointOfInterest.x=viewCoordinates.x/320.0f;
    //viewCoordinates.x = frameSize.width - viewCoordinates.x;
    pointOfInterest.y=1-(viewCoordinates.y/416.0f);
    
   // NSLog(@"Touch point:%f,%f",viewCoordinates.x,viewCoordinates.y);
    //NSLog(@"Focus Point:%f,%f",pointOfInterest.x,pointOfInterest.y);    
    return pointOfInterest;
}

- (void) exposureAtPoint:(CGPoint)point
{
    AVCaptureDevice *device = [[self videoInput] device];
//    if ([device isExposurePointOfInterestSupported] && [device isExposureModeSupported:AVCaptureExposureModeContinuousAutoExposure]) {
        NSError *error;
        if ([device lockForConfiguration:&error]) {
            [device setExposurePointOfInterest:point];
            [device setExposureMode:AVCaptureExposureModeContinuousAutoExposure];
            [device unlockForConfiguration];
        } 
   // }    
}


- (void)tapToFocus:(CGPoint)point
{
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
   // NSLog(@"Camera focus point : %f, %f", device.focusPointOfInterest.x, device.focusPointOfInterest.y);
   // NSLog(@"Camera expose point:%f, %f", device.exposurePointOfInterest.x, device.exposurePointOfInterest.y);
    if ([device isExposureModeSupported:AVCaptureExposureModeLocked]||
        [device isExposureModeSupported:AVCaptureExposureModeAutoExpose]||
        [device isFocusModeSupported:AVCaptureExposureModeContinuousAutoExposure])
    {
        CGPoint convertedFocusPoint = [self convertToPointOfInterestFromViewCoordinates:point];
        [self focusAtPoint:convertedFocusPoint];
        [self exposureAtPoint:convertedFocusPoint];
        [self drawExposeBoxAtPointOfInterest:point];
    }
}

- (void)handleSingleTap:(id)tapPointValue
{
    [self tapToFocus:[tapPointValue CGPointValue]];
}
    
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    if ([touches count] == 1) {
        UITouch *touch = [touches anyObject];
        CGPoint tapPoint = [touch locationInView:self.view];
        if ([touch tapCount] == 1) {
            [self performSelector:@selector(handleSingleTap:) withObject:[NSValue valueWithCGPoint:tapPoint] afterDelay:0.3];
        }
    }
}


    
@end
