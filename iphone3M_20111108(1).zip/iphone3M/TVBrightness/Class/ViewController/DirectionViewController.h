//
//  DirectionViewController.h
//  TVBrightness
//
//  Created by zhang on 10/20/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "PageContentViewController.h"
#import "define.h"

@interface DirectionViewController : PageContentViewController
{

}
@property(nonatomic,retain) IBOutlet UIImageView *imageView;
@property(nonatomic,retain) IBOutlet  UIButton *btnClose;


@end
