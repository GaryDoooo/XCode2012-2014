//
//  TVListAllViewController.h
//  TVBrightness
//
//  Created by zhang on 6/18/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ApplicationCell.h"
#import "DetailViewController.h"
#import "TVListAllViewController.h"
#import "FileManagerController.h"
#import "ASIHTTPRequest.h"
//#import "NSObject+SBJson.h"
#import "EGORefreshTableHeaderView.h"

#define ServerAddress @"127.0.0.1"

@interface TVListAllViewController : UIViewController <EGORefreshTableHeaderDelegate,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate> {
 
    UITableView *tabAllTVList;
    ApplicationCell *AppCell;
    NSString *strBrand;
    NSMutableArray *arrayList;
    NSMutableArray *arrayListWithBrand;
    NSMutableArray *arrayDisplay;
    UINavigationBar *NavBar;
    UISearchBar *SearchBar;
    NSMutableData *responseData;
    EGORefreshTableHeaderView *_refreshHeaderView;
    BOOL _reloading;
}


@property (nonatomic,retain) IBOutlet ApplicationCell *AppCell;
@property (nonatomic,retain) IBOutlet UITableView *tabAllTVList;
@property (nonatomic,retain) IBOutlet UINavigationBar *NavBar;
@property (nonatomic,retain) IBOutlet UISearchBar *SearchBar;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil withString:(NSString *)string;
-(void)btnRating:(id)sender;
-(void)GetTVList;
@end
