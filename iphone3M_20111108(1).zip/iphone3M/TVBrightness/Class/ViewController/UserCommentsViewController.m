//
//  UserCommentsViewController.m
//  HDTVBrightness
//
//  Created by zhang on 5/27/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "UserCommentsViewController.h"


@implementation UserCommentsViewController
@synthesize subView,Email,TVicon,UserComments;
@synthesize BrRatingView,AgRatingView,EgRatingView;
@synthesize btnSubmit,btnChooseItem;
@synthesize PopupView,Scrollview,labLocation,AppCell;
@synthesize tempRatingValue,ActivityView,TVPickView,tabModelNumberList,tabTopTenList,NavBar;


#pragma mark - Init
-(void)initNavigationBar
{
    NavBar.frame=CGRectMake(0,0,320,44);
    NavBar.tintColor=[UIColor colorWithRed:0.97 green:0.59 blue:0.14 alpha:1.00];
    NavBar.topItem.title=@"Top 10 排名榜";
    UIBarButtonItem *CloseButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"完成" style:UIBarButtonItemStyleDone target:self action:@selector(btnDone:)];   
    [NavBar.topItem setRightBarButtonItem:CloseButtonItem];
    [CloseButtonItem release];
}

-(void)initTopTenTableView
{
    tabTopTenList.delegate=self;
    tabTopTenList.dataSource=self;
    tabTopTenList.frame=CGRectMake(0, 40, 320, 382);
    tabTopTenList.separatorStyle=UITableViewCellSeparatorStyleNone;
    tabTopTenList.scrollsToTop=YES;
}

-(void)initModelNumberTableView
{
    tabModelNumberList.frame=CGRectMake(0, 152, 320, 250);
    tabModelNumberList.delegate=self;
    tabModelNumberList.dataSource=self;
}

-(void)initPickView
{
    selected=0;
    TVPickView.frame=CGRectMake(0, 0, 320, 150);
    TVPickView.showsSelectionIndicator = YES;
    [TVPickView setBackgroundColor:[UIColor clearColor]];
    TVPickView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    TVPickView.delegate=self; 
    
    NSString *strBrandListPath=[[FileManagerController resourcePath]stringByAppendingPathComponent:@"TVBrandItem.plist"];
    dictBrandList=[[NSDictionary alloc]initWithContentsOfFile:strBrandListPath];
    if (dictBrandList) {
        
    }
    else
    {
        NSLog(@"找不到品牌列表！");
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"找不到品牌列表"
                                                            message:nil
                                                           delegate:nil
                                                  cancelButtonTitle:@"确定"
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release];
    }
    
    NSString *strInchListPath=[[FileManagerController resourcePath]stringByAppendingPathComponent:@"TVInchItem.plist"];
    dictInchList=[[NSDictionary alloc]initWithContentsOfFile:strInchListPath];
    
    if (dictInchList) {
        
    }
    else
    {
        NSLog(@"找不到尺寸列表！");
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"找不到品牌列表"
                                                            message:nil
                                                           delegate:nil
                                                  cancelButtonTitle:@"确定"
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release];
    }
    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(GetUserInfo:) name:@"CallUserCommentsView" object:nil];
    }
    return self;
}

-(void)GetUserInfo:(NSNotification *)aNotification 
{
    NSDictionary *dicUserInfo=[[NSDictionary alloc]initWithDictionary:[aNotification userInfo]];
   // NSLog(@"%@",dicUserInfo);
    tempRatingValue=[[dicUserInfo objectForKey:@"BrLevel"]floatValue];
    if(self.view)
    {
         BrRatingView.rating=tempRatingValue;
    }
    [dicUserInfo release];
}

- (void)dealloc
{
    //[SBJsonWriter release];
    [dictPlist release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

-(void)initRatingView:(UserRateView *)rateView
{
    rateView.notSelectedImage =[UIImage imageNamed:@"star_0.png"];
    rateView.halfSelectedImage =[UIImage imageNamed:@"star_half.png"];
    rateView.fullSelectedImage =[UIImage imageNamed:@"star_1.png"];
    rateView.rating =0;
    rateView.editable =YES;
    rateView.maxRating =5;
    rateView.delegate = self;
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initModelNumberTableView];
    [self initPickView];
    [self initTopTenTableView];
    [self initNavigationBar];
    arrayDetailList=[[NSMutableArray alloc]init];
    ViewUp=NO;
    [self initRatingView:AgRatingView];
    [self initRatingView:BrRatingView];
    [self initRatingView:EgRatingView];
    if (tempRatingValue) {
        BrRatingView.rating=tempRatingValue;
       // EgRatingView.editable=NO;
    }
    self.TVicon.image=[UIImage imageNamed:@"ico_01.png"];
    self.TVicon.backgroundColor=[UIColor clearColor];
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"bg.png"]];
    self.subView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"5.png"]];
    // Do any additional setup after loading the view from its nib.
    UserComments.layer.borderWidth = 4.0f;
    UserComments.layer.borderColor = [[UIColor blackColor] CGColor];
    UserComments.layer.cornerRadius = 20;
    UserComments.layer.masksToBounds = YES;
    
    UserComments.delegate=self;
    Email.delegate=self;
    
    CGSize size;
    size.width=145;
    size.height=50;
    [btnSubmit setBackgroundImage:[UIImage imageNamed:@"btn_01.png"] withSize:size ];
    CGSize buttomSize;
    buttomSize.width=304;
    buttomSize.height=34;
    [btnChooseItem setBackgroundImage:[UIImage imageNamed:@"button.png"]];
    
//    TVItemPickView.showsSelectionIndicator = YES;    
//    [TVItemPickView setBackgroundColor:[UIColor clearColor]];
//    TVItemPickView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
//    TVItemPickView.delegate=self;  //设置委托
    
    NSString *strPath=[[FileManagerController resourcePath]stringByAppendingPathComponent:@"TVBrandItem.plist"];
    dictPlist=[[NSDictionary alloc]initWithContentsOfFile:strPath];
    selectAtBrand=0;
    btnChooseItem.titleLabel.textColor=[UIColor whiteColor];
    btnChooseItem.titleLabel.text=@"选择电视型号";
    
    locmanager = [[CLLocationManager alloc] init]; 
	[locmanager setDelegate:self]; 
	[locmanager setDesiredAccuracy:kCLLocationAccuracyBest];	
    [locmanager startUpdatingLocation];
    
    Scrollview.frame=CGRectMake(0, 40, 320, 460);
    Scrollview.indicatorStyle=UIScrollViewIndicatorStyleWhite;
    Scrollview.clipsToBounds = YES;		// default is NO, we want to restrict drawing within our scrollview
    Scrollview.scrollEnabled = YES;
    Scrollview.delaysContentTouches = YES;
    Scrollview.bounces = NO;
    [Scrollview setContentSize:CGSizeMake(320,740)];
    [self.view addSubview:Scrollview];
    ActivityView.frame=CGRectMake(141, 212, 37, 37);
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Button action
-(void)btnDone:(id)sender
{
    [NavBar removeFromSuperview];
    [tabTopTenList removeFromSuperview];
}

-(void)timerupdata
{
	TimerCount ++;
	if (TimerCount>3) {
        [timer invalidate];
        [BackgroundView removeFromSuperview];
        [activityIndicator removeFromSuperview];
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"评论提交成功！"
                              message:@""
                              delegate:nil
                              cancelButtonTitle:@"确定"
                              otherButtonTitles:nil];
        [alert show];
        [alert release];

    }
    
}


-(IBAction)actionSubmitButton:(id)sender
{
    [self.view addSubview:ActivityView];
    //make sure modelnuber be selected
    if(0==btnChooseItem.titleLabel.text.length)
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"请选择电视机型号"
                                                            message:@""
                                                           delegate:nil
                                                  cancelButtonTitle:@"确定"
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release];
        [ActivityView removeFromSuperview];
        return;
    }
    //make sure all information be filled
    else if((0==BrRatingView.rating)||(0==AgRatingView.rating)||(0==EgRatingView.rating))
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"请给电视机打分"
                                                            message:@""
                                                           delegate:nil
                                                  cancelButtonTitle:@"确定"
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release];
        [ActivityView removeFromSuperview];
        return;
    }

    
    else if (0==UserComments.text.length) 
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"请填写评论"
                                                            message:@""
                                                           delegate:nil
                                                  cancelButtonTitle:@"确定"
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release];
        [ActivityView removeFromSuperview];
        return;
    }
    
    //Update current location
    if(0==labLocation.text.length)
    {
        [locmanager startUpdatingLocation];
    }
   // NSString *strLocation=labLocation.text;
   
    //set JSON data 
    NSMutableDictionary *dictJSON=[[NSMutableDictionary alloc]init];
    
    NSString *strUDID=[[UIDevice currentDevice] uniqueIdentifier];
    [dictJSON setObject:strUDID forKey:@"udid"];
    
    //NSString *strModelNumber=btnChooseItem.titleLabel.text;
    NSString *strModelNumber=btnChooseItem.titleLabel.text;
    [dictJSON setObject:strModelNumber forKey:@"modelNumber"];
    
    NSString *strBrightness=[NSString stringWithFormat:@"%.1f", BrRatingView.rating];
    [dictJSON setObject:strBrightness forKey:@"brightness"];
    
    NSString *strAngle=[NSString stringWithFormat:@"%.1f", AgRatingView.rating];
    [dictJSON setObject:strAngle forKey:@"viewAngle"];
    
    NSString *strEnergy=[NSString stringWithFormat:@"%.1f", EgRatingView.rating];
    [dictJSON setObject:strEnergy forKey:@"efficiency"];
    
    NSString *strEmail=Email.text;
    [dictJSON setObject:strEmail forKey:@"email"];
    
    NSString *strComments=UserComments.text;
    [dictJSON setObject:strComments forKey:@"comment"];
    
    NSString *strLatitude=[NSString stringWithFormat:@"%f",currentLocation.latitude];
    [dictJSON setObject:strLatitude forKey:@"latitude"];
    
    NSString *strLongitude=[NSString stringWithFormat:@"%f",currentLocation.longitude];
    [dictJSON setObject:strLongitude forKey:@"longitude"];
    
    responseData = [[NSMutableData data] retain];
    //send http request
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@/threem/service/clientservices/addcomment/",ServerAdress]]];
    [request setHTTPMethod:@"POST"];
    SBJsonWriter *JsonString=[[SBJsonWriter alloc]init];
    NSString *strJsonString=[JsonString stringWithObject:dictJSON];
    NSData *postData = [strJsonString dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    [request setHTTPBody:postData];
    NSDictionary *dictJsonHead=[NSDictionary dictionaryWithObject:@"application/json" forKey:@"Content-Type"];
    [request setAllHTTPHeaderFields:dictJsonHead];
    [NSURLConnection connectionWithRequest: request
                                  delegate: self];
    [dictJSON release];
    [JsonString release];

}

-(IBAction)actionChooseButton:(id)sender
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:TVPickView cache:YES];
    [self.view addSubview:TVPickView];
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.4];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:tabModelNumberList cache:YES];
    [self.view addSubview:tabModelNumberList];
    [UIView commitAnimations];
   
}

-(IBAction)HideKeyboard:(id)sender
{

}

#pragma mark - Model number Request
-(void)ListSortByBrightness:(NSInteger)Page
{
    [self.view addSubview:ActivityView];
    self.view.userInteractionEnabled=NO;
    responseData = [[NSMutableData data] retain];
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@/threem/service/clientservices/items/%d/10/Bri/",ServerAdress,Page]]];
    [request setHTTPMethod:@"POST"];
    NSDictionary *dictJsonHead=[NSDictionary dictionaryWithObject:@"application/json" forKey:@"Content-Type"];
    [request setAllHTTPHeaderFields:dictJsonHead];
    [NSURLConnection connectionWithRequest: request
                                  delegate: self];
}

-(void)getTopTenList
{
    [self ListSortByBrightness:1];
}

-(void)ModelNumberListRequestByBrand:(NSString *)brand
{
    [self.view addSubview:ActivityView];
    //[ActivityView startAnimating];
    self.view.userInteractionEnabled=NO;
    responseData = [[NSMutableData data] retain];
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@/threem/service/clientservices/items/b/%@/",ServerAdress,brand]]];
    [request setHTTPMethod:@"POST"];
    NSDictionary *dictJsonHead=[NSDictionary dictionaryWithObject:@"application/json" forKey:@"Content-Type"];
    [request setAllHTTPHeaderFields:dictJsonHead];
    [NSURLConnection connectionWithRequest: request
                                  delegate: self];
}

-(void)ModelNumberListRequestByInch:(NSString *)inch
{
    [self.view addSubview:ActivityView];
    self.view.userInteractionEnabled=NO;
    responseData = [[NSMutableData data] retain];
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@/threem/service/clientservices/items/i/%@",ServerAdress,inch]]];
    [request setHTTPMethod:@"POST"];
    NSDictionary *dictJsonHead=[NSDictionary dictionaryWithObject:@"application/json" forKey:@"Content-Type"];
    [request setAllHTTPHeaderFields:dictJsonHead];
    [NSURLConnection connectionWithRequest: request
                                  delegate: self];
}


-(void)SingleNumber:(NSString *)strModelNumber
{
    [self.view addSubview:ActivityView];
    self.view.userInteractionEnabled=NO;
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@/threem/service/clientservices/item/single/%@",ServerAdress,strModelNumber]]];
    [request setHTTPMethod:@"POST"];
    NSDictionary *dictJsonHead=[NSDictionary dictionaryWithObject:@"application/json" forKey:@"Content-Type"];
    [request setAllHTTPHeaderFields:dictJsonHead];
    [NSURLConnection connectionWithRequest: request
                                  delegate: self];
    
}


#pragma mark - RatingView delegate
- (void)rateView:(UserRateView *)rateView ratingDidChange:(float)rating {
    //do something here
}




#pragma mark - TextField/TextView delegate

-(void)textViewDidBeginEditing:(UITextView *)textView
{

}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range 
 replacementText:(NSString *)text
{
    // Any new character added is passed in as the "text" parameter
    if ([text isEqualToString:@"\n"]) {
        // Be sure to test for equality using the "isEqualToString" message
        [textView resignFirstResponder];
        
        // Return FALSE so that the final '\n' character doesn't get added
        return FALSE;
    }
    // For any other character return TRUE so that the text gets added to the view
    return TRUE;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string isEqualToString:@"\n"]) {
        // Be sure to test for equality using the "isEqualToString" message
        [textField resignFirstResponder];
        
        // Return FALSE so that the final '\n' character doesn't get added
        return FALSE;
    }
    // For any other character return TRUE so that the text gets added to the view
    return TRUE;
}

#pragma mark - PickerView delegate
- (void)selectRow:(NSInteger)row inComponent:(NSInteger)component animated:(BOOL)animated{
    return;
}

//设置列数
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)thePickerView {    
    return 2;
}

//返回数组总数
- (NSInteger)pickerView:(UIPickerView *)thePickerView numberOfRowsInComponent:(NSInteger)component { 
    if(0==component)
        return 2;
    else
    {
        if(0==selected)
            return [[dictBrandList objectForKey:@"Brand"]count];
        else
            return [[dictInchList objectForKey:@"Inch"]count];
    }
}

- (NSString *)pickerView:(UIPickerView *)thePickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (0==component) {
        if (0==row) 
            return @"按品牌";
        else
            return @"按尺寸";
    }
    else
    {
        if(0==selected)
            return [[dictBrandList objectForKey:@"Brand"]objectAtIndex:row];
        else
            return [[dictInchList objectForKey:@"Inch"]objectAtIndex:row];
    }
    
}

//触发事件
- (void)pickerView:(UIPickerView *)thePickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component 
{
    if (0==component) {
        switch (row) 
        {
            case 0:
                selected=0;
                break;
            case 1:
                selected=1;
                break; 
        }
        [TVPickView reloadComponent:1];
    }
    else
    {
        if (0==selected) 
        {
            NSString *strBrand=[[dictBrandList objectForKey:@"Brand"]objectAtIndex:row];
            [self ModelNumberListRequestByBrand:strBrand];
        }
        else
        {
            NSString *strInch=[[dictInchList objectForKey:@"Inch"]objectAtIndex:row];
            [self ModelNumberListRequestByInch:strInch];
        }
    }
}

#pragma mark - HTTP request delegate
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
   // NSLog(@"%@",response);
    [responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {

    NSString *receiveString =[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    //NSLog(@"%@",receiveString);
    [responseData appendData:data];
    [receiveString release];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
   // [responseData appendData:data];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"请求超时！"
                                                        message:@"网络无应答."//[error localizedDescription]
                                                       delegate:nil
                                              cancelButtonTitle:@"确定"
                                              otherButtonTitles:nil];
    [alertView show];
    [alertView release];
    [ActivityView removeFromSuperview];
    self.view.userInteractionEnabled=YES;
}



- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    
    ActivityView.hidden=YES;
    self.view.userInteractionEnabled=YES;
    NSString *responseString = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
    NSDictionary *dictValue=[responseString JSONValue];

    [responseString release];
    //if receive data isn't empty
    if (dictValue) {
        if((1==[[dictValue objectForKey:@"status"]intValue])&&([[dictValue objectForKey:@"stag"]isEqualToString:@"comment"]))
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"评论提交成功！"
                                                                message:nil
                                                               delegate:nil
                                                      cancelButtonTitle:@"确定"
                                                      otherButtonTitles:nil];
            [alertView show];
            [alertView release];
            //[ActivityView removeFromSuperview];
            btnChooseItem.titleLabel.text=@"请选择电视机型号";
            UserComments.text=@"";
            Email.text=@"";
            AgRatingView.rating=0.0;
            BrRatingView.rating=0.0;
            EgRatingView.rating=0.0;
            [self getTopTenList];
        }
        else if((1==[[dictValue objectForKey:@"status"]intValue])&&(([[dictValue objectForKey:@"stag"]hasPrefix:@"items/b/"])||([[dictValue objectForKey:@"stag"]hasPrefix:@"items/i/"])))
        {
            arrayModelNumber=[[dictValue objectForKey:@"Message"]retain];
            [tabModelNumberList reloadData];
        }
        else if((![[dictValue objectForKey:@"stag"]hasPrefix:@"items/b/"]) &&(![[dictValue objectForKey:@"stag"]hasPrefix:@"items/i/"])&&(![[dictValue objectForKey:@"stag"]hasPrefix:@"item/single/"]))
        {
            //NSLog(@"%@",[dictValue objectForKey:@"Message"]);
            [arrayDetailList addObjectsFromArray:[dictValue objectForKey:@"Message"]];
            [tabTopTenList reloadData];
            [self.view addSubview:tabTopTenList];
            [self.view addSubview:NavBar];
        }
        else if([[dictValue objectForKey:@"stag"]hasPrefix:@"item/single/"])
        {
            //NSLog(@"%@",[[[dictValue objectForKey:@"Message"]objectAtIndex:0]objectForKey:@"液晶电视能效指数"]);
            //int PowerLevel=[[[[dictValue objectForKey:@"Message"]objectAtIndex:0]objectForKey:@"液晶电视能效指数"]flaotValue];
            float PowerLevel=[[[[dictValue objectForKey:@"Message"]objectAtIndex:0]objectForKey:@"液晶电视能效指数"]floatValue];
            if (PowerLevel>1.5) 
            {
                self.EgRatingView.rating=5;
            }
            else if ((PowerLevel>1.2)&&(PowerLevel<1.5))
            {
                self.EgRatingView.rating=4;
            }
            else if ((PowerLevel>0.9)&&(PowerLevel<1.2))
            {
                self.EgRatingView.rating=3;
            }
            else if ((PowerLevel>0.6)&&(PowerLevel<0.9))
            {
                self.EgRatingView.rating=2;
            }
            else if (PowerLevel<0.6)
            {
                self.EgRatingView.rating=1;
            }
            else
            {
                self.EgRatingView.rating=0;
            }
        }
        else
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"评论提交失败！"
                                                                message:nil
                                                               delegate:nil
                                                      cancelButtonTitle:@"确定"
                                                      otherButtonTitles:nil];
            [alertView show];
            [alertView release];
            [ActivityView removeFromSuperview];
        }
    }
    else
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"评论提交失败！"
                                                            message:nil
                                                           delegate:nil
                                                  cancelButtonTitle:@"确定"
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release];
    }
    
}

#pragma mark - TableView delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(tabModelNumberList==tableView)
    {
        if (arrayModelNumber) 
            return [arrayModelNumber count];
        else
            return 0;
    }
    else
    {
        return 10;
    }
    
}	

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tabModelNumberList==tableView)
    {
        static NSString *CellIdentifier = @"Cell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
        }
        cell.selectedBackgroundView = [[[UIView alloc] initWithFrame:cell.frame] autorelease];
        cell.selectedBackgroundView.backgroundColor = [UIColor orangeColor];
        cell.textLabel.textColor=[UIColor whiteColor];
        cell.textLabel.text=[arrayModelNumber objectAtIndex:[indexPath row]];
        cell.backgroundColor=[UIColor clearColor];
        UIImageView *backgroundView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"img_listbg_s.png"]];

        cell.backgroundView= backgroundView;
        [backgroundView release];
         return cell;
    }
    else
    {
        static NSString *CellIdentifier = @"ApplicationCell";
        ApplicationCell *cell = (ApplicationCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        
        if (cell == nil)
        {
            [[NSBundle mainBundle] loadNibNamed:@"IndividualSubviewsBasedApplicationCell" owner:self options:nil];
            cell = AppCell;
            self.AppCell = nil;
        }
        cell.selectedBackgroundView = [[[UIView alloc] initWithFrame:cell.frame] autorelease];
        cell.selectedBackgroundView.backgroundColor = [UIColor orangeColor];
        cell.useDarkBackground =YES;
        cell.backgroundColor=[UIColor clearColor];
        cell.backgroundView= [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"img_listbg_s.png"]] autorelease];
        NSString *strIconName=[NSString stringWithFormat:@"%d.jpg",([indexPath row]+1)%23];
        cell.selectedBackgroundView.backgroundColor = [UIColor clearColor];
        cell.icon=[UIImage imageNamed:strIconName];
        cell.name=[[arrayDetailList objectAtIndex:[indexPath row]]objectForKey:@"型号"];
        cell.publisher=[[arrayDetailList objectAtIndex:[indexPath row]]objectForKey:@"商标"];
        cell.rating=[[[arrayDetailList objectAtIndex:[indexPath row]]objectForKey:@"brightness"]intValue];
        cell.accessoryType=UITableViewCellAccessoryNone;
        return cell;
        
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    btnChooseItem.titleLabel.text=[arrayModelNumber objectAtIndex:[indexPath row]];
    [self SingleNumber:[arrayModelNumber objectAtIndex:[indexPath row]]];
    [tabModelNumberList removeFromSuperview];
    [TVPickView removeFromSuperview];
}


-(CGFloat)tableView:(UITableView*)tableView  heightForRowAtIndexPath:(NSIndexPath*) indexPath
{	
    if(tabModelNumberList==tableView)
        return 40;
    else
        return 73;
}



#pragma mark - Location delegate
- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation 
{ 
	CLLocationCoordinate2D loc = [newLocation coordinate];
    currentLocation=loc;
    NSString *strLocation=[NSString stringWithFormat:@"%f,%f",loc.latitude,loc.longitude];
    labLocation.text=strLocation;
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error 
{ 
	
}


@end
