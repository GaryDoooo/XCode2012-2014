//
//  UserCommentsViewController.h
//  HDTVBrightness
//
//  Created by zhang on 5/27/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "UserRateView.h"
#import "MyButton.h"
#import "FileManagerController.h"

#import <MapKit/MapKit.h>
#import <MapKit/MKMapView.h>
#import <MapKit/MKAnnotation.h>
#import <MapKit/MKAnnotationView.h>
#import "SBJsonWriter.h"
#import "define.h"


@interface UserCommentsViewController : UIViewController<UserRateViewDelegate,UITextFieldDelegate,UITextViewDelegate,UIPickerViewDelegate,CLLocationManagerDelegate,UITableViewDelegate,UITableViewDataSource> {
    UIView *subView;
    //UILabel *TVTitle;
    UITextField *Email;
    UIImageView *TVicon;
    UITextView *UserComments;
    UserRateView *BrRatingView;
    UserRateView *AgRatingView;
    UserRateView *EgRatingView;
    BOOL ViewUp;
    MyButton *btnSubmit;
    MyButton *btnChooseItem;
    //UIPickerView *TVItemPickView;
    UIView *PopupView;
    
    NSInteger TimerCount;
    NSInteger selectAtBrand;
    NSDictionary *dictPlist;
    NSTimer *timer ;
    UIActivityIndicatorView *activityIndicator;
    UIView *BackgroundView;
    CLLocationManager *locmanager;
    
    UIScrollView *Scrollview;
    UILabel *labLocation;
    CLLocationCoordinate2D currentLocation;
    float tempRatingValue;
    NSMutableData *responseData;
    UIView *ActivityView;
    UIPickerView *TVPickView;
    
    NSDictionary *dictBrandList;
    NSDictionary *dictInchList;
    NSInteger selected;
    UITableView *tabModelNumberList;
    UITableView *tabTopTenList;
    NSArray *arrayModelNumber;
     ApplicationCell *AppCell;
     NSMutableArray *arrayDetailList;
     UINavigationBar *NavBar;
}

@property (nonatomic,retain)IBOutlet UIView *subView;
//@property (nonatomic,retain)IBOutlet UILabel *TVTitle;
@property (nonatomic,retain)IBOutlet UITextField * Email;
@property (nonatomic,retain)IBOutlet UIImageView *TVicon;
@property (nonatomic,retain)IBOutlet UITextView *UserComments;
@property (nonatomic,retain)IBOutlet UserRateView *BrRatingView;
@property (nonatomic,retain)IBOutlet UserRateView *AgRatingView;
@property (nonatomic,retain)IBOutlet UserRateView *EgRatingView;
@property (nonatomic,retain)IBOutlet MyButton *btnSubmit;
@property (nonatomic,retain)IBOutlet MyButton *btnChooseItem;
//@property (nonatomic,retain)IBOutlet UIPickerView *TVItemPickView;
@property (nonatomic,retain)IBOutlet UIView *PopupView;
@property (nonatomic,retain)IBOutlet UIScrollView *Scrollview;
@property (nonatomic,retain)IBOutlet UILabel *labLocation;
@property (nonatomic,retain)IBOutlet  UIView *ActivityView;
@property (readwrite) float tempRatingValue;
@property(nonatomic,retain)IBOutlet UIPickerView *TVPickView;
@property(nonatomic,retain)IBOutlet UITableView *tabModelNumberList;
@property(nonatomic,retain)IBOutlet UITableView *tabTopTenList;
@property(nonatomic,retain)IBOutlet ApplicationCell *AppCell;
@property(nonatomic,retain)IBOutlet UINavigationBar *NavBar;

-(IBAction)HideKeyboard:(id)sender;
-(IBAction)actionChooseButton:(id)sender;
-(IBAction)actionSubmitButton:(id)sender;

@end


