//
//  DetailViewController.m
//  TVBrightness
//
//  Created by zhang on 6/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "DetailViewController.h"


@implementation DetailViewController

@synthesize TableView,NavBar,ScrollView;
@synthesize dictTVinfo=dictTVinfo_;
@synthesize iconImage,AppCell,CloseButton;


#pragma mark -initialize
-(void)initCloseButton
{
    CloseButton.frame=CGRectMake(265, 86, 25, 25);
    [CloseButton setBackgroundImage:[UIImage imageNamed:@"close.png"] withSize:CloseButton.frame.size];
    [CloseButton addTarget:self action:@selector(btnClose:) forControlEvents:UIControlEventTouchDown];
}

-(void)initScrollView
{
    ScrollView.center= self.view.center;
    ScrollView.backgroundColor=[UIColor clearColor];
    ScrollView.layer.cornerRadius = 20.0;
    ScrollView.layer.borderColor = [UIColor grayColor].CGColor;
    ScrollView.layer.borderWidth = 2.0;
    ScrollView.layer.backgroundColor=(CGColorRef)[UIColor clearColor];
    ScrollView.delegate=self;
    
    ScrollView.pagingEnabled = YES;
    ScrollView.contentSize = CGSizeMake(ScrollView.frame.size.width * kNumberOfPages, ScrollView.frame.size.height);
    ScrollView.showsHorizontalScrollIndicator = NO;
    ScrollView.showsVerticalScrollIndicator = NO;
    ScrollView.scrollsToTop = NO;
    ScrollView.delegate = self;
    
    [self loadScrollViewWithPage:0];
    [self loadScrollViewWithPage:1];
    [self loadScrollViewWithPage:2];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil withObject:(NSDictionary *)dictionary
{
    self=[super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) 
    {
        dictTVinfo_=dictionary;
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - ScrollView delegate
- (void)loadScrollViewWithPage:(int)page
{
    if (page < 0)
        return;
    if (page >= kNumberOfPages)
        return;

    PageContentViewController *Content = [[PageContentViewController alloc] initWithPageNumber:page];
    CGRect frame = ScrollView.frame;
    frame.origin.x = frame.size.width * page;
    frame.origin.y = 0;
    Content.view.frame = frame;
    Content.view.backgroundColor=[UIColor clearColor];
    Content.TextView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"popup.png"]];
    Content.TextView.textColor=[UIColor whiteColor];
    Content.TextView.frame=CGRectMake(0, 0, 280, 300);
    Content.TextView.editable=NO;
    Content.PageControl.frame=CGRectMake(0,280, 280, 20);
    Content.PageControl.numberOfPages=3;
    Content.PageControl.currentPage=page;
    Content.PageControl.backgroundColor=[UIColor clearColor];
    [ScrollView addSubview:Content.view];
    [Content release];

}


 
- (void)scrollViewDidScroll:(UIScrollView *)sender
{
//    CGFloat pageWidth = ScrollView.frame.size.width;
//    int page = floor((ScrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;

}

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)newScrollView
{
//    CGFloat pageWidth = ScrollView.frame.size.width;
//    float fractionalPage = ScrollView.contentOffset.x / pageWidth;
//    NSInteger nearestNumber = lround(fractionalPage);
}


-(void)btnClose:(id)sender
{
    [ScrollView removeFromSuperview];
    [CloseButton removeFromSuperview];
}

-(void)btnBack:(id)sender
{
    [ScrollView removeFromSuperview];
    [CloseButton removeFromSuperview];
    [self.view removeFromSuperview];
}


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    TableView.delegate=self;
    TableView.dataSource=self;
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"bg.png"]];
        NavBar.tintColor=[UIColor colorWithRed:0.97 green:0.59 blue:0.14 alpha:1.00];
    
    UIButton *back =[[UIButton alloc] initWithFrame:CGRectMake(200, 25, 55, 30)]; 
    [back addTarget:self action:@selector(btnBack:) forControlEvents:UIControlEventTouchUpInside];
    [back setImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    UIBarButtonItem *backButtonItem = [[UIBarButtonItem alloc] initWithCustomView:back];
    NavBar.topItem.leftBarButtonItem = backButtonItem;
    [self initScrollView];
    [self initCloseButton];
    [back release];
    [backButtonItem release];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}


- (void)viewWillAppear:(BOOL)animated {
	
	[super viewWillAppear:animated]; 
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - instants method
-(void)TVInfoTransmit:(NSDictionary *)dict
{
    self.dictTVinfo=dict;
    [TableView reloadData];
}


#pragma mark - Table view data source and delegate

-(NSInteger)EnergyCaculate:(NSInteger)Power Inch:(NSInteger)inch
{
     switch (inch) {
        //26 inch
    case 26:
        if((70-Power)>0)
            return (70-Power)*4*356/1000*0.61;
        else
            return 0;
        break;
        //32 inch
    case 32:
        if((85-Power)>0)
            return (85-Power)*4*356/1000*0.61;
        else
            return 0;
        //37 inch
    case 37:
        if((120-Power)>0)
            return (120-Power)*4*356/1000*0.61;
        else
            return 0;
        //inch 40
    case 40:
        if((140-Power)>0)
            return (140-Power)*4*356/1000*0.61;
        else
            return 0;
        //inch 42
    case 42:
        if((160-Power)>0)
            return (160-Power)*4*356/1000*0.61;
        else
            return 0;   
        //inch 46
    case 46:
        if((180-Power)>0)
            return (180-Power)*4*356/1000*0.61;
        else
            return 0; 
        //inch 47
    case 47:
        if((200-Power)>0)
            return (200-Power)*4*356/1000*0.61;
        else
            return 0; 
        //inch 55
    case 55:
        if((220-Power)>0)
            return (220-Power)*4*356/1000*0.61;
        else
            return 0; 
    default:
        if((240-Power)>0)
            return (240-Power)*4*356/1000*0.61;
        else
            return 0; 
     }
}


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return @"电视机信息";
            break;
        case 1:
            return @"年均节省电量";
            break;
        case 2:
            return @"性能指数";
            break;
        case 3:
            return @"主要性能参数";
            break;
        default:
            break;
}
    
    if(0==section)
    {
        return @"电视机信息";
    }
    else
    {
        return @"待定";
    }
}

-(NSInteger)numberOfSectionsInTableView:(UITableView*)tableView {
    
    return 4;
}


-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section {
    	
    switch (section) {
        case 0:
            return 1;
            break;
        case 1:
            return 1;
            break;
        case 2:
            return 3;
            break;
        case 3:
            return 10;
            break;
        
        default:
            return 0;
    }
   
}


-(UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath {
    
   
    if((0==[indexPath row])&&(0==[indexPath section]))
    {
        //static NSString *CellIdentifier = @"ApplicationCell";
        //ApplicationCell  *cell= (ApplicationCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        ApplicationCell  *cell;//=[[ApplicationCell alloc]init];
        //NSLog(@"section=%d,row=%d",[indexPath section],[indexPath row]);
//        if (nil==cell)
//        {
            [[NSBundle mainBundle] loadNibNamed:@"IndividualSubviewsBasedApplicationCell1" owner:self options:nil];
            cell = AppCell;
            self.AppCell = nil;
     //   }
        //NSLog(@"%@",dictTVinfo_);
        //NSDictionary *dicTemp=[dictTVinfo_ objectForKey:@")"];
        cell.name=[dictTVinfo_  objectForKey:@"型号"];
        cell.publisher=[dictTVinfo_ objectForKey:@"商标"];
        cell.icon=[UIImage imageNamed:@"ico_01.png"];
        cell.rating1=[[dictTVinfo_ objectForKey:@"brightness"]floatValue];
        cell.rating2=[[dictTVinfo_ objectForKey:@"viewangle"]floatValue];
        cell.rating3=[[dictTVinfo_ objectForKey:@"efficiency"]floatValue];
        cell.userInteractionEnabled=NO;
        cell.accessoryType=UITableViewCellAccessoryNone;
        cell.backgroundColor=[UIColor clearColor];
        UIImageView *backgroundView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"detail_bg_1.png"]];

        cell.backgroundView= backgroundView;
        [backgroundView release];
        return cell;
    }
    else //if(  ([indexPath row]>0)&&([indexPath row]<3) )
    {
        static NSString *CellIdentifier1 = @"ApplicationCell1";
        ApplicationCell  *cell1= (ApplicationCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
        if (nil==cell1)
        {
            [[NSBundle mainBundle] loadNibNamed:@"IndividualSubviewsBasedApplicationCell2" owner:self options:nil];
            cell1 = AppCell;
            self.AppCell= nil;
        }
        cell1.backgroundColor=[UIColor clearColor];
        
        // section two 
        if (2==[indexPath section]) 
        {
           
            cell1.accessoryType=UITableViewCellAccessoryDetailDisclosureButton;
            cell1.userInteractionEnabled=YES;
            UIImageView *backgroundView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"detail_bg_2.png"]];

            cell1.backgroundView=backgroundView;
            [backgroundView release];
            switch ([indexPath row]) {
                //NSLog(@"section=%d,row=%d",[indexPath section],[indexPath row]);
                case 0:
                    cell1.name=@"能效";
                    cell1.publisher=[dictTVinfo_ objectForKey:@"efficiency"];
                    break;
                case 1:
                    cell1.name=@"亮度";
                    cell1.publisher=[dictTVinfo_ objectForKey:@"brightness"];
                    break;
                case 2:
                    cell1.name=@"视角";
                    cell1.publisher=[dictTVinfo_ objectForKey:@"viewangle"];
                    break;
               
                default:
                    break;
            }
        }
        else if (3==[indexPath section])
        {
           
            cell1.accessoryType=UITableViewCellAccessoryNone;
            cell1.userInteractionEnabled=NO;
            UIImageView *backgroundView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"detail_bg_2.png"]];
            cell1.backgroundView=backgroundView;
            [backgroundView release];
            switch ([indexPath row]) {
                //NSLog(@"section=%d,row=%d",[indexPath section],[indexPath row]);
                case 0:
                    cell1.name=@"生 产 者";
                    cell1.publisher=[dictTVinfo_ objectForKey:@"生产者"];
                    break;
                case 1:
                    cell1.name=@"能效指数";
                    cell1.publisher=[dictTVinfo_ objectForKey:@"液晶电视能效指数"];
                    break;
                case 2:
                    cell1.name=@"尺寸 (英寸)";
                    cell1.publisher=[dictTVinfo_ objectForKey:@"screeninch"];
                    break;
                case 3:
                    cell1.name=@" 功率 (w)";
                    cell1.publisher=[dictTVinfo_ objectForKey:@"额定功率（W）"];
                    break;
                case 4:
                    cell1.name=@"频率(Hz)";
                    cell1.publisher=[dictTVinfo_ objectForKey:@"频率（Hz）"];
                    break;
                case 5:
                    cell1.name=@"水平分辨率";
                    cell1.publisher=[dictTVinfo_ objectForKey:@"固有分辨力-水平（mm）"];
                    break;
                case 6:
                    cell1.name=@"垂直分辨率";
                    cell1.publisher=[dictTVinfo_ objectForKey:@"固有分辨力-垂直（mm）"];
                    break;
                case 7:
                    cell1.name=@"屏幕宽度(mm)";
                    cell1.publisher=[dictTVinfo_ objectForKey:@"屏幕有效尺寸-宽（mm）"];
                    break;
                case 8:
                    cell1.name=@"屏幕长度(mm)";
                    cell1.publisher=[dictTVinfo_ objectForKey:@"屏幕有效尺寸-长（mm）"];
                    break;
                case 9:
                    cell1.name=@"待机功率(w)";
                    cell1.publisher=[dictTVinfo_ objectForKey:@"LCD被动待机功率（W）"];
                    break;
                default:
                    cell1.name=nil;
                    cell1.publisher=nil;
                    break;
            }
        }
        else if (1==[indexPath section])
        {
            cell1.accessoryType=UITableViewCellAccessoryNone;
            cell1.userInteractionEnabled=NO;
           // cell1.backgroundView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"img_listbg_s.png"]];
            UIImageView *backgroundView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"detail_bg_2.png"]];
            cell1.backgroundView=backgroundView;
            [backgroundView release];
            cell1.name=@"年节省电费(元)";
            int Inch=[[dictTVinfo_ objectForKey:@"screeninch"]intValue];
            int Power=[[dictTVinfo_ objectForKey:@"额定功率(W)"]intValue];
            cell1.publisher=[NSString stringWithFormat:@"%d",[self EnergyCaculate:Power Inch:Inch]];
        }
        return cell1;
    }
}



-(CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath {
    if((0==[indexPath row])&&(0==[indexPath section]))
    {
        return 112;
    }
    else
    {
        return 44;
    }
}


-(void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath {
    if(2==[indexPath section])
    {
        [self.view addSubview:ScrollView];
        [self.view addSubview:CloseButton];
    }
}


@end
