//
//  MyButton.h
//  Decoder
//
//  Created by zhang on 12/24/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface MyButton: UIButton {
	
}

- (void)setBackgroundImage:(UIImage*)image;
- (void)setBackgroundImageByName:(NSString*)imageName;
-(void)setBackgroundImage:(UIImage*)image withSize:(CGSize)size;
@end

