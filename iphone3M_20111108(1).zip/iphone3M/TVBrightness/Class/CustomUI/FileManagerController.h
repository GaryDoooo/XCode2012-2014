//
//  FileManagerController.h
//
//
//

#import <Foundation/Foundation.h>



@interface FileManagerController : NSObject {

}

+(NSString *)resourcePath;
+ (NSString *)documentPath;
+ (NSArray *)allFilesInFolder:(NSString *)folderName;
+ (NSArray *)allContentsInPath:(NSString *)directoryPath;
+ (NSArray *)allFilesInPathAndItsSubpaths:(NSString *)directoryPath;

@end
