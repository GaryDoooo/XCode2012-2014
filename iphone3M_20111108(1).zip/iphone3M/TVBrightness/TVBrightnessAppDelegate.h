//
//  TVBrightnessAppDelegate.h
//  TVBrightness
//
//  Created by zhang on 5/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TVBrightnessViewController;

@interface TVBrightnessAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet TVBrightnessViewController *viewController;

@end
