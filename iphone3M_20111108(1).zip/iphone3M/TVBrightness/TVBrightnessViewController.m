//
//  TVBrightnessViewController.m
//  TVBrightness
//
//  Created by zhang on 5/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TVBrightnessViewController.h"


static NSArray* tabBarItems = nil;

@implementation TVBrightnessViewController
@synthesize TabBar;
@synthesize ScrollView,CloseButton;

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle
-(void)initScrollView
{
    //ScrollView.center= self.view.center;
    ScrollView.backgroundColor=[UIColor clearColor];
    ScrollView.layer.borderColor = [UIColor grayColor].CGColor;
    ScrollView.layer.borderWidth = 2.0;
    //ScrollView.layer.cornerRadius = 20.0;
    
    ScrollView.layer.backgroundColor=(CGColorRef)[UIColor clearColor];
    ScrollView.pagingEnabled = YES;
    ScrollView.contentSize = CGSizeMake(ScrollView.frame.size.width * kNumberOfPages_DirectionView, ScrollView.frame.size.height);
    ScrollView.frame=CGRectMake(0, 0, 320, ScrollView.frame.size.height);
    ScrollView.showsHorizontalScrollIndicator = NO;
    ScrollView.showsVerticalScrollIndicator = NO;
    ScrollView.scrollsToTop = NO;
    ScrollView.delegate = self;
    
    [self loadScrollViewWithPage:0];
    [self loadScrollViewWithPage:1];
    [self loadScrollViewWithPage:2];
    [self loadScrollViewWithPage:3];
    
}

-(void)initCloseButton
{
    CloseButton.frame=CGRectMake(295, 0, 25, 25);
    [CloseButton setBackgroundImage:[UIImage imageNamed:@"close.png"] withSize:CloseButton.frame.size];
    [CloseButton addTarget:self action:@selector(btnClose:) forControlEvents:UIControlEventTouchDown];
}

- (void) initAllView
{
    // Set up some fake view controllers each with a different background color so we can visually see the controllers getting swapped around
    TVListViewController *detailController1 = [[[TVListViewController alloc] init] autorelease];
    
    CameraViewController *detailController2 = [[[CameraViewController alloc] init] autorelease];
    //detailController2.view.backgroundColor = [UIColor greenColor];
    
    UserCommentsViewController *detailController3 = [[[UserCommentsViewController alloc] init] autorelease];
    //detailController3.view.backgroundColor = [UIColor blueColor];
    
    UserGuideViewController *detailController4 = [[[UserGuideViewController alloc] init] autorelease];
    
    
    tabBarItems = [[NSArray arrayWithObjects:
                    [NSDictionary dictionaryWithObjectsAndKeys:@"zoom_2.png", @"image", detailController1, @"viewController", nil],
                    [NSDictionary dictionaryWithObjectsAndKeys:@"photo_2.png", @"image", detailController2, @"viewController", nil],
                    [NSDictionary dictionaryWithObjectsAndKeys:@"doc_2.png", @"image", detailController3, @"viewController", nil],
                    [NSDictionary dictionaryWithObjectsAndKeys:@"information.png", @"image", detailController4, @"viewController", nil],
                    nil]retain];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    prefs = [NSUserDefaults standardUserDefaults];
    
    [super viewDidLoad];
    [self initAllView];
    [self initScrollView];
    [self initCloseButton];
    // Use the TabBarGradient image to figure out the tab bar's height (22x2=44)
    UIImage* tabBarGradient = [UIImage imageNamed:@"TabBarGradient.png"];
    
    // Create a custom tab bar passing in the number of items, the size of each item and setting ourself as the delegate
    self.TabBar = [[[CustomTabBar alloc] initWithItemCount:tabBarItems.count itemSize:CGSizeMake(self.view.frame.size.width/tabBarItems.count, tabBarGradient.size.height*2) tag:0 delegate:self] autorelease];
    
    // Place the tab bar at the bottom of our view
    TabBar.frame = CGRectMake(0,self.view.frame.size.height-(tabBarGradient.size.height*2),self.view.frame.size.width, tabBarGradient.size.height*2);
    [self.view addSubview:TabBar];
    
    // Select the first tab
    [TabBar selectItemAtIndex:0];
    [self touchDownAtItemAtIndex:0];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(CallUserCommentsView) name:@"CallUserCommentsView" object:nil];
    
    // Guide only appear in first time
    if(![prefs boolForKey:@"NoGuide"])
    {
        [self.view addSubview:ScrollView];
        [self.view addSubview:CloseButton];
        [prefs setBool:YES forKey:@"NoGuide"];
    }
   
}


-(void)CallUserCommentsView
{
    [self touchDownAtItemAtIndex:2];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(IBAction)btnClose:(id)sender
{
    [ScrollView removeFromSuperview];
    [CloseButton removeFromSuperview];
}


#pragma mark - PageView method
- (void)loadScrollViewWithPage:(int)page
{
    if (page < 0)
        return;
    if (page >= kNumberOfPages_DirectionView)
        return;
    
     DirectionViewController *Content = [[DirectionViewController alloc] initWithPageNumber:page];
    CGRect frame = ScrollView.frame;
    frame.origin.x = frame.size.width * page;
    frame.origin.y = 0;
    Content.view.frame = frame;
    Content.view.backgroundColor=[UIColor clearColor];

    
    
    Content.PageControl.numberOfPages=4;
    Content.PageControl.currentPage=page;
    Content.PageControl.backgroundColor=[UIColor clearColor];
    [ScrollView addSubview:Content.view];
    [Content release];
    
}



#pragma mark - Custom tabbar delegate

- (UIImage*) imageFor:(CustomTabBar*)tabBar atIndex:(NSUInteger)itemIndex
{
    // Get the right data
    NSDictionary* data = [tabBarItems objectAtIndex:itemIndex];
    // Return the image for this tab bar item
    return [UIImage imageNamed:[data objectForKey:@"image"]];
}

- (UIImage*) backgroundImage
{
    // The tab bar's width is the same as our width
    CGFloat width = self.view.frame.size.width;
    // Get the image that will form the top of the background
    UIImage* topImage = [UIImage imageNamed:@"TabBarGradient.png"];
    
    // Create a new image context
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(width, topImage.size.height*2), NO, 0.0);
    
    // Create a stretchable image for the top of the background and draw it
    UIImage* stretchedTopImage = [topImage stretchableImageWithLeftCapWidth:0 topCapHeight:0];
    [stretchedTopImage drawInRect:CGRectMake(0, 0, width, topImage.size.height)];
    
    // Draw a solid black color for the bottom of the background
    [[UIColor blackColor] set];
    CGContextFillRect(UIGraphicsGetCurrentContext(), CGRectMake(0, topImage.size.height, width, topImage.size.height));
    
    // Generate a new image
    UIImage* resultImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return resultImage;
}

// This is the blue background shown for selected tab bar items
- (UIImage*) selectedItemBackgroundImage
{
    return [UIImage imageNamed:@"TabBarItemSelectedBackground.png"];
}

// This is the glow image shown at the bottom of a tab bar to indicate there are new items
- (UIImage*) glowImage
{
    UIImage* tabBarGlow = [UIImage imageNamed:@"TabBarGlow.png"];
    
    // Create a new image using the TabBarGlow image but offset 4 pixels down
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(tabBarGlow.size.width, tabBarGlow.size.height-4.0), NO, 0.0);
    
    // Draw the image
    [tabBarGlow drawAtPoint:CGPointZero];
    
    // Generate a new image
    UIImage* resultImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return resultImage;
}

// This is the embossed-like image shown around a selected tab bar item
- (UIImage*) selectedItemImage
{
    // Use the TabBarGradient image to figure out the tab bar's height (22x2=44)
    UIImage* tabBarGradient = [UIImage imageNamed:@"TabBarGradient.png"];
    CGSize tabBarItemSize = CGSizeMake(self.view.frame.size.width/tabBarItems.count, tabBarGradient.size.height*2);
    UIGraphicsBeginImageContextWithOptions(tabBarItemSize, NO, 0.0);
    
    // Create a stretchable image using the TabBarSelection image but offset 4 pixels down
    [[[UIImage imageNamed:@"TabBarSelection.png"] stretchableImageWithLeftCapWidth:4.0 topCapHeight:0] drawInRect:CGRectMake(0, 4.0, tabBarItemSize.width, tabBarItemSize.height-4.0)];  
    
    // Generate a new image
    UIImage* selectedItemImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return selectedItemImage;
}

- (UIImage*) tabBarArrowImage
{
    return [UIImage imageNamed:@"TabBarNipple.png"];
}

- (void) touchDownAtItemAtIndex:(NSUInteger)itemIndex
{
    // Remove the current view controller's view
    UIView* currentView = [self.view viewWithTag:SELECTED_VIEW_CONTROLLER_TAG];
    [currentView removeFromSuperview];
    
    // Get the right view controller
    NSDictionary* data = [tabBarItems objectAtIndex:itemIndex];
    UIViewController* viewController = [data objectForKey:@"viewController"];
    
    // Use the TabBarGradient image to figure out the tab bar's height (22x2=44)
    UIImage* tabBarGradient = [UIImage imageNamed:@"TabBarGradient.png"];
    
    // Set the view controller's frame to account for the tab bar
    viewController.view.frame = CGRectMake(0,0,self.view.frame.size.width, self.view.frame.size.height-(tabBarGradient.size.height*2));
    
    // Se the tag so we can find it later
    viewController.view.tag = SELECTED_VIEW_CONTROLLER_TAG;
    
    // Add the new view controller's view
    [self.view insertSubview:viewController.view belowSubview:TabBar];
    
    // In 1 second glow the selected tab
    [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(addGlowTimerFireMethod:) userInfo:[NSNumber numberWithInteger:itemIndex] repeats:NO];
    
}

- (void)addGlowTimerFireMethod:(NSTimer*)theTimer
{
    // Remove the glow from all tab bar items
    for (NSUInteger i = 0 ; i < tabBarItems.count ; i++)
    {
        [TabBar removeGlowAtIndex:i];
    }
    
    // Then add it to this tab bar item
    [TabBar glowItemAtIndex:[[theTimer userInfo] integerValue]];
}

@end
