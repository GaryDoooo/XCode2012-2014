//
//  TVBrightnessViewController.h
//  TVBrightness
//
//  Created by zhang on 5/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TVListViewController.h"
#import "CameraViewController.h"
#import "UserCommentsViewController.h"
#import "CustomTabBar.h"
#import "UserGuideViewController.h"

#define SELECTED_VIEW_CONTROLLER_TAG 98456345

@interface TVBrightnessViewController : UIViewController<CustomTabBarDelegate,UIScrollViewDelegate> {
    
    CustomTabBar *TabBar;
    NSUserDefaults *prefs;
}

@property (nonatomic, retain) IBOutlet MyButton *CloseButton;
@property (nonatomic, retain) IBOutlet CustomTabBar *TabBar;
@property (nonatomic,retain) IBOutlet UIScrollView *ScrollView;

- (void)loadScrollViewWithPage:(int)page;
- (void)initScrollView;
-(void)initCloseButton;

@end

