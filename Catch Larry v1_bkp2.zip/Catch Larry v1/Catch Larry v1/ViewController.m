//
//  ViewController.m
//  Catch Larry v1
//
//  Created by Herrick Wang on 12-1-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

@synthesize subbuttonview;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    int j=0;
    //UIView *tempv;
    for(int i=0;i<[subbuttonview.subviews count];i++){
        tempv=[subbuttonview.subviews objectAtIndex:i];
        NSLog(@"found view.subview index:%d",i);
        if(tempv.tag > 99) {
            buttonindex[j++]=i;
            tempv.hidden = true;
        }
    }
    NSLog(@"buttonindex found:%d",j);
    subbuttonview.hidden = true;
    
    totalrounds =9;
    difficulty =1;
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

-(void)stoprun{
    NSString *comment;
    
    //stop timer.....
    [timer invalidate];
    
    int minscore=1000-75*(totalrounds-1);
    score=(score-minscore)*100/(maxscore-minscore);
    scorelabel.text = [NSString stringWithFormat:
                       @"Final score(0-100): %d",score];
    if(score>90){
        comment =[NSString stringWithFormat:@"You CHEAT..."];
    }else if(score >75){
        comment =[NSString stringWithFormat:@"Good Play"];        
    } else if(score>60){
        comment =[NSString stringWithFormat:
                  @"Passed. Try again."]; 
    }else if(score >30){
        comment =[NSString stringWithFormat:
                  @"Failed Try again..."];
    } else {
        comment =[NSString stringWithFormat:
                  @"Big room to improve"];
    }
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"You...." message:comment
                delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    
    //animation back
    [UIView beginAnimations:@"flipping view" context:nil];
    [UIView setAnimationDuration:1];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
    [UIView setAnimationTransition: UIViewAnimationTransitionFlipFromRight
                           forView:subbuttonview cache:YES];
    [subbuttonview setHidden:YES];
    [UIView commitAnimations];
    
}

-(void)onTimer{
    int showbutton;
    
    if(timing>=0) {
        score = score - 10;
        //maxscore = maxscore -10;
    }
    scorelabel.text = [NSString stringWithFormat:
                       @"Score: %d",score];
    switch (timing++) {
        case 0:
        {
         showbutton = rand() % 18;
        tempv=[subbuttonview.subviews 
                   objectAtIndex:buttonindex[showbutton]];
            /*if(tempv.tag <110) {
                maxscore = maxscore + 50;
            } else {
                maxscore =maxscore - 50;
            }*/
        tempv.hidden=false;   
        }
            break;
        case 4:{
            timing=0; 
            tempv.hidden=true;
            if(tempv.tag <110){
                score = score - 50;
            } else {
                score = score + 100;
            }
            if(totalrounds==rounds++) [self stoprun];
        }
            break;
        default:
            break;
    }

}

- (IBAction)startrun:(id)sender{
    //int showbutton;
    //UIView *tempv;
    
    score = 1000; maxscore =1000 + (totalrounds +1)*50;
    scorelabel.text = [NSString stringWithFormat:
                       @"Score: %d",score];
    //subbuttonview.hidden = false;
    [UIView beginAnimations:@"flipping view" context:nil];
    [UIView setAnimationDuration:1];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
    [UIView setAnimationTransition: UIViewAnimationTransitionFlipFromRight
     forView:subbuttonview cache:YES];
    //[self.view​removeFromSuperview];​​​​
    //[UIView commitAnimations];
    [subbuttonview setHidden:NO];
    [UIView commitAnimations];
    
    // Start Timer...
    timer = [NSTimer scheduledTimerWithTimeInterval:
             0.1*(3-diffcultysetting.selectedSegmentIndex) 
                                             target:self
                                   selector:@selector(onTimer)
                                   userInfo:nil
                                    repeats:YES];
    timing = -10; rounds=0; 
    
    //[self.view ];
    //[self view];
    
    /*for (int i=0;i<10;i++){
        showbutton = rand() % 18; //rand is int radom number
        NSLog(@"show button index: %d",showbutton);
        tempv=[subbuttonview.subviews 
               objectAtIndex:buttonindex[showbutton]];
        tempv.hidden=false;
        for(int j=0;j<1000000;j++)for(int k=0;k<10000;k++);
        tempv.hidden=true;
    }

    subbuttonview.hidden = true;*/
    
}

-(IBAction)clicklarry:(id)sender{
    score=score+50;
    scorelabel.text = [NSString stringWithFormat:
                       @"Score: %d",score];
    timing=4;
   
}

-(IBAction)clickalant:(id)sender{
    score=score-50;
    scorelabel.text = [NSString stringWithFormat:
                       @"Score: %d",score];
    timing=4;
 
}

//-(IBAction)changediff:(id)sender{
    
//}

-(IBAction)changerounds:(id)sender{
    roundslabel.text = [NSString stringWithFormat:
                        @"%d Rounds",(int)roundslider.value];
    totalrounds = (int)roundslider.value - 1;
    //NSLog(@"round setting @d")
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

@end
