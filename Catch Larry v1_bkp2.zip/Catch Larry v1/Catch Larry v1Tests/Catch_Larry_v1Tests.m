//
//  Catch_Larry_v1Tests.m
//  Catch Larry v1Tests
//
//  Created by Herrick Wang on 12-1-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "Catch_Larry_v1Tests.h"

@implementation Catch_Larry_v1Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Catch Larry v1Tests");
}

@end
