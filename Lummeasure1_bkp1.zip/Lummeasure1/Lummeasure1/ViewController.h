//
//  ViewController.h
//  Lummeasure1
//
//  Created by Garry Du on 12-1-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
//@class CIDetector;

@interface ViewController : UIViewController <AVCaptureVideoDataOutputSampleBufferDelegate>
{
	IBOutlet UIView *previewView;
    IBOutlet UILabel *outputlabel;
    IBOutlet UIButton *measurebutton;

	AVCaptureVideoPreviewLayer *previewLayer;
	AVCaptureStillImageOutput *stillImageOutput;
	UIImage *square;
    
    BOOL underprocessing;

}

-(IBAction)captureNow:(id)sender;

- (void)teardownAVCapture;
int calc_avg_grey_level(UIImage *image);
//float getRGBAsFromImage(UIImage* image, int xx, int yy, int count);
//- (UIImage *)imageWithColor:(UIColor *)color andSize:(CGSize)size;

@end
