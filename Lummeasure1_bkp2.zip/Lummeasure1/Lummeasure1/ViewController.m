//
//  ViewController.m
//  Lummeasure1
//
//  Created by Herrick Wang on 12-1-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import <CoreImage/CoreImage.h>
#import <ImageIO/ImageIO.h>
#import <AssertMacros.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <math.h>
//#import "AppKit/NSBitmapImageRep.h"

// used for KVO observation of the @"capturingStillImage" property to perform flash bulb animation
static const NSString *AVCaptureStillImageIsCapturingStillImageContext = @"AVCaptureStillImageIsCapturingStillImageContext";

@interface ViewController (InternalMethods)
- (void)setupAVCapture;
- (void)teardownAVCapture;
//- (void)drawFaceBoxesForFeatures:(NSArray *)features forVideoBox:(CGRect)clap orientation:(UIDeviceOrientation)orientation;
@end

@implementation ViewController

/*
float getRGBAsFromImage(UIImage* image, int xx, int yy, int count)
{
    //NSMutableArray *result = [NSMutableArray arrayWithCapacity:count];
    
    // First get the image into your data buffer
    
    double result =0;
    
    CGImageRef imageRef = [image CGImage];
    NSUInteger width = CGImageGetWidth(imageRef);
    NSUInteger height = CGImageGetHeight(imageRef);
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    unsigned char *rawData = malloc(height * width * 4);
    NSUInteger bytesPerPixel = 4;
    NSUInteger bytesPerRow = bytesPerPixel * width;
    NSUInteger bitsPerComponent = 8;
    CGContextRef context = CGBitmapContextCreate(rawData, width, height,
                                                 bitsPerComponent, bytesPerRow, colorSpace,
                                                 kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);
    CGColorSpaceRelease(colorSpace);
    
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), imageRef);
    CGContextRelease(context);
    
    // Now your rawData contains the image data in the RGBA8888 pixel format.
    int byteIndex = (bytesPerRow * yy) + xx * bytesPerPixel;
    for (int ii = 0 ; ii < count ; ++ii)
    {
        CGFloat red   = (rawData[byteIndex]     * 1.0) / 255.0;
        CGFloat green = (rawData[byteIndex + 1] * 1.0) / 255.0;
        CGFloat blue  = (rawData[byteIndex + 2] * 1.0) / 255.0;
        //CGFloat alpha = (rawData[byteIndex + 3] * 1.0) / 255.0;
        byteIndex += 4;
        
        result  = result + red*0.3 + green*0.56 +blue*0.14;
        
        //UIColor *acolor = [UIColor colorWithRed:red green:green blue:blue alpha:alpha];
        //[result addObject:acolor];
    }
    
    free(rawData);
    
    return result/count;
}


- (UIImage *)imageWithColor:(UIColor *)color andSize:(CGSize)size 
{
    CGRect rect = CGRectMake(0.0f, 0.0f, size.height, size.width);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}
*/
 
 
int calc_avg_grey_level(UIImage *image){
    //float grayaverageall; 
    int startx,starty,boxwidth, endy;
    
    unsigned long result =0;
    
    //////////from ref : convert UIimage to bitmap
    CGImageRef imageRef = [image CGImage];
    NSUInteger width = CGImageGetWidth(imageRef);
    NSUInteger height = CGImageGetHeight(imageRef);
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    unsigned char *rawData = malloc(height * width * 4);
    NSUInteger bytesPerPixel = 4;
    NSUInteger bytesPerRow = bytesPerPixel * width;
    NSUInteger bitsPerComponent = 8;
    CGContextRef context = CGBitmapContextCreate(rawData, width, height,
                                                 bitsPerComponent, bytesPerRow, colorSpace,
                                                 kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);
    CGColorSpaceRelease(colorSpace);
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), imageRef);
    CGContextRelease(context);
    /////////////////////////////////
    
    startx = round(width*0.4);
    starty = round(height *0.4);
    boxwidth = startx/2;
    endy = starty/2+starty;
    //grayaverageall =0;
    
    for(int yy=starty;yy<=endy;yy++){
//        result += getRGBAsFromImage(image, startx, yy, boxwidth);

        unsigned long byteIndex = (bytesPerRow * yy) + startx * bytesPerPixel;
        for (int ii = 0 ; ii < boxwidth ; ++ii)
        {
            //CGFloat red   = (rawData[byteIndex]     * 1.0) / 255.0;
            //CGFloat green = (rawData[byteIndex + 1] * 1.0) / 255.0;
            //CGFloat blue  = (rawData[byteIndex + 2] * 1.0) / 255.0;
            //CGFloat alpha = (rawData[byteIndex + 3] * 1.0) / 255.0;
            
            result  = result + rawData[byteIndex]*0.3 + rawData[byteIndex + 1]*0.56 +rawData[byteIndex + 2]*0.14;
            
            byteIndex += 4;
            
            //UIColor *acolor = [UIColor colorWithRed:red green:green blue:blue alpha:alpha];
            //[result addObject:acolor];
        }
    }
    free(rawData);
    result = result/starty;
    result =result *2;
    return (result/boxwidth);
}

-(void) viewDidAppear:(BOOL)animated
{
    underprocessing = true;
    square = [UIImage imageNamed:@"squarePNG.png"];
    
    AVCaptureSession *session = [[AVCaptureSession alloc] init];
    session.sessionPreset = AVCaptureSessionPresetMedium;
    
    //CALayer *viewLayer = [previewView layer]; // self.vImagePreview.layer;
    //NSLog(@"viewLayer = %@", viewLayer);
    
    previewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:session];
    [previewLayer setVideoGravity:AVLayerVideoGravityResizeAspectFill]; 
    
    previewLayer.frame = previewView.bounds;
    [previewView.layer addSublayer:previewLayer];
    
    ///////////////Draw a cross on the preview area
    CGRect layerrect;
    layerrect = [previewLayer frame];
    CALayer *featureLayer = [CALayer new];
    [featureLayer setContents:(id)[square CGImage]];
    //[featureLayer setName:@"FaceLayer"];
    [previewLayer addSublayer:featureLayer];
    layerrect.origin.x=layerrect.size.width/2-35;
    layerrect.origin.y=layerrect.size.height/2-55;
    layerrect.size.height=70;
    layerrect.size.width=70;
    [featureLayer setFrame:layerrect];
    //[featureLayer release];
    /////////////////////////////
    
    currentdevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    
    NSError *error = nil;
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:currentdevice error:&error];
    if (!input) {
        // Handle the error appropriately.
        NSLog(@"ERROR: trying to open camera: %@", error);
    }
    [session addInput:input];
    
    stillImageOutput = [[AVCaptureStillImageOutput alloc] init];
    NSDictionary *outputSettings = [[NSDictionary alloc] initWithObjectsAndKeys: AVVideoCodecJPEG, AVVideoCodecKey, nil];
    [stillImageOutput setOutputSettings:outputSettings];
    
    [session addOutput:stillImageOutput];
    
    [session startRunning];
    
    underprocessing = false;
    
    [super viewDidAppear:animated];
}



-(IBAction) captureNow:(id)sender
{
    //[measurebutton setHidden:YES];
    //[self.view setNeedsDisplay];
if(!underprocessing){
    underprocessing =true;
    AVCaptureConnection *videoConnection = nil;
    for (AVCaptureConnection *connection in stillImageOutput.connections)
    {
        for (AVCaptureInputPort *port in [connection inputPorts])
        {
            if ([[port mediaType] isEqual:AVMediaTypeVideo] )
            {
                videoConnection = connection;
                break;
            }
        }
        if (videoConnection) { break; }
    }
    
    NSLog(@"about to request a capture from: %@", stillImageOutput);
    [stillImageOutput captureStillImageAsynchronouslyFromConnection:videoConnection completionHandler: ^(CMSampleBufferRef imageSampleBuffer, NSError *error)
     {
         CFDictionaryRef exifAttachments = CMGetAttachment( imageSampleBuffer, kCGImagePropertyExifDictionary, NULL);
         if (exifAttachments)
         {
             // Do something with the attachments.
             NSLog(@"attachements: %@", exifAttachments);
         }
         else
             NSLog(@"no attachments");
         
         NSData *imageData = [AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:imageSampleBuffer];
         
         
         CFDataRef imagedataref=(__bridge CFDataRef)imageData;
         CGImageSourceRef mySourceRef = CGImageSourceCreateWithData(imagedataref, nil);
         NSDictionary *myMetadata = (__bridge NSDictionary *) CGImageSourceCopyPropertiesAtIndex(mySourceRef,0,NULL);
         NSDictionary *exifDic = [myMetadata objectForKey:(__bridge NSString *)kCGImagePropertyExifDictionary];
         NSDictionary *tiffDic = [myMetadata objectForKey:(__bridge NSString *)kCGImagePropertyTIFFDictionary];
         NSLog(@"exifDic properties: %@", myMetadata); //all data
         float rawShutterSpeed = [[exifDic objectForKey:(__bridge NSString *)kCGImagePropertyExifExposureTime] floatValue];
         int decShutterSpeed = (1 / rawShutterSpeed);
         NSLog(@"Camera %@",[tiffDic objectForKey:(__bridge NSString *)kCGImagePropertyTIFFModel]);
         NSLog(@"Focal Length %@mm",[exifDic objectForKey:(__bridge NSString *)kCGImagePropertyExifFocalLength]);
         NSLog(@"Shutter Speed %@", [NSString stringWithFormat:@"1/%d", decShutterSpeed]);
         NSLog(@"Aperture f/%@",[exifDic objectForKey:(__bridge NSString *)kCGImagePropertyExifFNumber]);
         NSNumber *ExifISOSpeed = [[exifDic objectForKey:(__bridge NSString*)kCGImagePropertyExifISOSpeedRatings] objectAtIndex:0];
         NSLog(@"ISO %i",[ExifISOSpeed integerValue]);
         NSLog(@"Taken %@",[exifDic objectForKey:(__bridge NSString*)kCGImagePropertyExifDateTimeDigitized]);
         
         UIImage *uiimagedata = [[UIImage alloc] initWithData:imageData];
         
         //uiimagedata = [self imageWithColor:[UIColor colorWithRed:1.0f green:0.0f blue:0.0f alpha:1.0f] andSize:CGSizeMake(640, 480)];
         
         int avggraylevel = calc_avg_grey_level(uiimagedata);
         double WebE=7.84/[ExifISOSpeed integerValue]*decShutterSpeed;
         double est_lum = 0.0496*pow(WebE*avggraylevel,1.1013);
         
         NSLog(@"average grey level is %d:", avggraylevel);
         
         outputlabel.text =[NSString stringWithFormat:
                            @"Br: %@ \t\tS: %@ \nf/%@ \t\t\tISO %i \nCtr. APL %d   lum:%3.1f Nit",
                            [exifDic objectForKey:(__bridge NSString *)kCGImagePropertyExifBrightnessValue],
                            [NSString stringWithFormat:@"1/%d", decShutterSpeed],
                            [exifDic objectForKey:(__bridge NSString *)kCGImagePropertyExifFNumber],
                            [ExifISOSpeed integerValue],
                            avggraylevel,
                            est_lum];
         
         //NSBitmapImageRep *zNsBitmapImageRepObj = [[NSBitmapImageRep alloc] initWithData:imageData];
         //CIImage *ciimagedata=[[CIImage alloc] initWithData:imageData];
         
         //CIContext *ciContext = [CIContext alloc];// options:nil];
         //[ciContext drawImage:ciimagedata atPoint:CGPointZero fromRect:[ciimagedata extent]];
         
         //CGContextRelease(ciContext);
         
         
         ///UIImage *image = [[UIImage alloc] initWithData:imageData];
         
         //self.vImage.image = image;
     }];
    underprocessing =false;
}
    //[measurebutton setHidden:NO];
}

/*
 // clean up capture setup
- (void)teardownAVCapture
{
	//[videoDataOutput release];
	if (videoDataOutputQueue)
		dispatch_release(videoDataOutputQueue);
	[stillImageOutput removeObserver:self forKeyPath:@"isCapturingStillImage"];
	//[stillImageOutput release];
	[previewLayer removeFromSuperlayer];
	//[previewLayer release];
}*/

-(IBAction)turnOnTorch:(id)sender{
    
    [currentdevice lockForConfiguration:nil];
    if(TorchSwitch.on){
        currentdevice.torchMode=AVCaptureTorchModeOn;
    } else {
        currentdevice.torchMode=AVCaptureTorchModeOff;
    }
    [currentdevice unlockForConfiguration];
}

-(IBAction)turnOnFocusing:(id)sender{
    [currentdevice lockForConfiguration:nil];
    if(FocusSwitch.on){
        currentdevice.focusMode=AVCaptureFocusModeContinuousAutoFocus;
    } else {
        currentdevice.focusMode=AVCaptureFocusModeLocked;
    }
    [currentdevice unlockForConfiguration];
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    TorchSwitch.on=false;
    FocusSwitch.on=true;
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

/*- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}*/

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    //if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
    
        	return (interfaceOrientation == UIInterfaceOrientationPortrait);
    
    //return (interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
    //} else {
    //    return YES;
    //}
}

@end
