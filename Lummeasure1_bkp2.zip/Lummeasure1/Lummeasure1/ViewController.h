//
//  ViewController.h
//  Lummeasure1
//
//  Created by Garry Du on 12-1-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
//@class CIDetector;

@interface ViewController : UIViewController <AVCaptureVideoDataOutputSampleBufferDelegate>
{
	IBOutlet UIView *previewView;
    IBOutlet UILabel *outputlabel;
    IBOutlet UIButton *measurebutton;
    IBOutlet UISwitch *TorchSwitch;
    IBOutlet UISwitch *FocusSwitch;

	AVCaptureVideoPreviewLayer *previewLayer;
	AVCaptureStillImageOutput *stillImageOutput;
    AVCaptureDevice *currentdevice;
	UIImage *square;
    
    BOOL underprocessing;

}

-(IBAction)captureNow:(id)sender;
-(IBAction)turnOnTorch:(id)sender;
-(IBAction)turnOnFocusing:(id)sender;

- (void)teardownAVCapture;
int calc_avg_grey_level(UIImage *image);
//float getRGBAsFromImage(UIImage* image, int xx, int yy, int count);
//- (UIImage *)imageWithColor:(UIColor *)color andSize:(CGSize)size;

@end
